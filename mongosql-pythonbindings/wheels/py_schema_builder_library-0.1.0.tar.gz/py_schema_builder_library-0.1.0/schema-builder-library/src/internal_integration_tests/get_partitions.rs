use crate::internal_integration_tests::consts::{
    DEFAULT_COLLECTION_INFO, DEFAULT_HINT, DEFAULT_PARTITION_KEY, MISMATCHED_ID_TYPES_PARTITIONS,
    SMALL_PARTITIONS,
};
use test_utils::schema_builder_library_integration_test_consts::{
    MISMATCHED_TYPES_COLL_NAME, MISMATCHED_TYPES_DB_NAME,
};

macro_rules! test_get_partitions {
    ($test_name:ident, expected = $expected:expr, input_db = $input_db:expr, input_coll = $input_coll:expr $(, ignore = $ignore:expr)?) => {

        #[cfg(feature = "integration")]
        #[tokio::test]
        $(#[ignore = $ignore])?
        async fn $test_name() {
            use super::create_mdb_service;
            use crate::CollectionInfo;
            use crate::partitioning::{get_partitions, Partition};

            #[allow(unused)]
            use mongodb::bson::Bson;
            #[allow(unused)]
            use test_utils::schema_builder_library_integration_test_consts::{
                DATA_DOC_SIZE_IN_BYTES, LARGE_COLL_NAME, LARGE_ID_MIN, NONUNIFORM_DB_NAME,
                NUM_DOCS_PER_LARGE_PARTITION, SMALL_COLL_NAME, SMALL_COLL_SIZE_IN_MB, SMALL_ID_MIN,
                UNIFORM_DB_NAME, UNITARY_COLL_NAME,
            };

            let service = create_mdb_service().await;
            let collection_info = CollectionInfo {
                name: $input_coll.to_string(),
                ..DEFAULT_COLLECTION_INFO.clone()
            };

            let expected: Vec<Partition> = $expected.to_vec();

            let actual_res = get_partitions(&service, $input_db, collection_info).await;
            match actual_res {
                Err(err) => assert!(false, "unexpected error: {err:?}"),
                Ok(actual_partitioned_collection) => {
                    let a_len = actual_partitioned_collection.partitions.len();
                    let e_len = expected.len();
                    // The large tests here have potential to fail, be aware. Failures should be
                    // uncommon.
                    assert!(
                        a_len >= e_len,
                        "actual partition #{a_len} is not greater than or equal to expected partition #{e_len}"
                    );

                    let partition_key = actual_partitioned_collection.partition_key;
                    let hint = actual_partitioned_collection.hint;

                    assert!(partition_key == *DEFAULT_PARTITION_KEY, "partition key was not _id, was {partition_key}");

                    assert!(hint == *DEFAULT_HINT, "hint was not Some(mongodb::options::Hint::Keys(doc! {{\"_id\": 1}})), was {hint:?}");

                }
            }
        }
    };
}

test_get_partitions!(
    uniform_small,
    expected = SMALL_PARTITIONS,
    input_db = UNIFORM_DB_NAME,
    input_coll = SMALL_COLL_NAME
);

test_get_partitions!(
    uniform_unit,
    expected = [Partition {
        min: Bson::MinKey,
        max: Bson::MaxKey,
        is_max_bound_inclusive: true
    }],
    input_db = UNIFORM_DB_NAME,
    input_coll = UNITARY_COLL_NAME
);

test_get_partitions!(
    nonuniform_small,
    expected = SMALL_PARTITIONS,
    input_db = NONUNIFORM_DB_NAME,
    input_coll = SMALL_COLL_NAME
);

test_get_partitions!(
    mismatched_types_small,
    expected = MISMATCHED_ID_TYPES_PARTITIONS,
    input_db = MISMATCHED_TYPES_DB_NAME,
    input_coll = MISMATCHED_TYPES_COLL_NAME
);

#[cfg(feature = "integration")]
#[tokio::test]
async fn one_doc_collection() {
    use super::create_mdb_service;
    use crate::{errors::Error, partitioning::get_partitions};
    use mongodb::error::{CommandError, ErrorKind};
    use test_utils::schema_builder_library_integration_test_consts::UNIFORM_DB_NAME;

    let service = create_mdb_service().await;

    let actual_res =
        get_partitions(&service, UNIFORM_DB_NAME, DEFAULT_COLLECTION_INFO.clone()).await;
    match actual_res {
        Err(Error::DataServiceError(e)) => match *e.kind {
            ErrorKind::Command(CommandError { code: 26, .. }) => {}
            ref kind => panic!("unexpected DataService error kind: {kind:?}"),
        },
        Err(err) => panic!("unexpected error: {err:?}"),
        Ok(actual) => panic!("expected error but got: {actual:?}"),
    }
}

#[cfg(feature = "integration")]
#[tokio::test]
async fn empty_collection() {
    use super::create_mdb_service;
    use crate::{errors::Error, partitioning::get_partitions};
    use mongodb::error::{CommandError, ErrorKind};
    use test_utils::schema_builder_library_integration_test_consts::UNIFORM_DB_NAME;

    let service = create_mdb_service().await;

    let actual_res =
        get_partitions(&service, UNIFORM_DB_NAME, DEFAULT_COLLECTION_INFO.clone()).await;
    match actual_res {
        Err(Error::DataServiceError(e)) => match *e.kind {
            ErrorKind::Command(CommandError { code: 26, .. }) => {}
            ref kind => panic!("unexpected DataService error kind: {kind:?}"),
        },
        Err(err) => panic!("unexpected error: {err:?}"),
        Ok(actual) => panic!("expected error but got: {actual:?}"),
    }
}
