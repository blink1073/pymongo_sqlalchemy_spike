use thiserror::Error;

#[derive(Debug, Error)]
pub enum Error<ServiceError: core::error::Error> {
    #[error("JsonSchemaFailure")]
    JsonSchemaFailure,
    #[error("BsonFailure")]
    BsonFailure,
    #[error("Unable to get collection stats for {0}")]
    NoCollectionStats(String),
    #[error("Unable to get bounds for collection: {0}")]
    NoBounds(String),
    #[error("No timeField specified for timeseries collection '{0}'")]
    NoTimeFieldSpecified(String),
    #[error("No count field specified for collection '{0}'")]
    MissingCountFieldForCollection(String),
    #[error("Collection {0} appears to be empty")]
    EmptyCollection(String),
    #[error("Error in DataService: {0}")]
    DataServiceError(ServiceError),
    #[error("Schema Error {0}")]
    SchemaError(mongosql::schema::Error),
    #[error("NoCollection {0}")]
    NoCollection(String),
}

impl<S: core::error::Error> From<mongosql::schema::Error> for Error<S> {
    fn from(value: mongosql::schema::Error) -> Self {
        match value {
            mongosql::schema::Error::BsonFailure(_) => Self::BsonFailure,
            mongosql::schema::Error::JsonSchemaFailure => Self::JsonSchemaFailure,
            _ => Self::SchemaError(value),
        }
    }
}
