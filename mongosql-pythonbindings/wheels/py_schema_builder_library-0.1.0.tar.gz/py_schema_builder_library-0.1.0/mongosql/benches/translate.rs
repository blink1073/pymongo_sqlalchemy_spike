use agg_ast::definitions::Namespace;
use criterion::{Criterion, black_box, criterion_group, criterion_main};
use mongosql::{
    SchemaCheckingMode, Translation,
    catalog::Catalog,
    map,
    options::{ExcludeNamespacesOption, SqlOptions},
    schema::ANY_DOCUMENT,
    translate_sql,
};
use pprof::criterion::{Output, PProfProfiler};

fn translate(sql: &str) -> Translation {
    let current_db = "mydb";
    let catalog = Catalog::new(map! {
        Namespace {database: "mydb".into(), collection: "foo".into()} => ANY_DOCUMENT.clone(),
    });
    translate_sql(
        current_db,
        sql,
        &catalog,
        SqlOptions::new(
            ExcludeNamespacesOption::IncludeNamespaces,
            SchemaCheckingMode::Relaxed,
        ),
    )
    .unwrap()
}

fn criterion_benchmark(c: &mut Criterion) {
    c.bench_function("translate_simple", |b| {
        b.iter(|| translate(black_box("select * from foo where a > 5")))
    });
}

criterion_group!(
    name = benches;
    config = Criterion::default().with_profiler(PProfProfiler::new(100, Output::Flamegraph(None)));
    targets = criterion_benchmark
);
criterion_main!(benches);
