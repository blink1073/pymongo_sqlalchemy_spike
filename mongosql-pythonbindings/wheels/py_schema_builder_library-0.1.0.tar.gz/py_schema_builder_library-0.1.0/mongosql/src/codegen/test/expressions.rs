macro_rules! test_codegen_expression {
    ($func_name:ident, expected = $expected:expr, input = $input:expr) => {
        #[test]
        fn $func_name() {
            use crate::codegen::MqlCodeGenerator;
            let expected = $expected;
            let input = $input;

            let r#gen = MqlCodeGenerator {};
            assert_eq!(expected, r#gen.codegen_expression(input));
        }
    };
}
mod date_function {
    use crate::air::{
        DateFunction::*, DateFunctionApplication, DatePart::*, Expression::*, LiteralValue::*,
        SqlOperator::*, SqlSemanticOperator,
    };
    use bson::bson;

    test_codegen_expression!(
        dateadd,
        expected = Ok(
            bson!({"$dateAdd": {"startDate": "$$NOW", "unit": {"$literal": "year"}, "amount": {"$literal": 5}}})
        ),
        input = DateFunction(DateFunctionApplication {
            function: Add,
            unit: Year,
            args: vec![
                Literal(Integer(5)),
                SqlSemanticOperator(SqlSemanticOperator {
                    op: CurrentTimestamp,
                    args: vec![],
                }),
            ],
        })
    );

    test_codegen_expression!(
        datediff,
        expected = Ok(
            bson!({"$dateDiff": {"startDate": "$$NOW", "endDate": "$$NOW", "unit": {"$literal": "year"}, "startOfWeek": {"$literal": "sunday"}}})
        ),
        input = DateFunction(DateFunctionApplication {
            function: Diff,
            unit: Year,
            args: vec![
                SqlSemanticOperator(SqlSemanticOperator {
                    op: CurrentTimestamp,
                    args: vec![],
                }),
                SqlSemanticOperator(SqlSemanticOperator {
                    op: CurrentTimestamp,
                    args: vec![],
                }),
                Literal(String("sunday".to_string())),
            ],
        })
    );

    test_codegen_expression!(
        datetrunc,
        expected = Ok(
            bson!({"$dateTrunc": {"date": "$$NOW", "unit": {"$literal": "year"}, "startOfWeek": {"$literal": "sunday"}}})
        ),
        input = DateFunction(DateFunctionApplication {
            function: Trunc,
            unit: Year,
            args: vec![
                SqlSemanticOperator(SqlSemanticOperator {
                    op: CurrentTimestamp,
                    args: vec![],
                }),
                Literal(String("sunday".to_string())),
            ],
        })
    );
}

mod switch {
    use crate::air::{
        Expression::*, LiteralValue::*, MqlOperator::*, MqlSemanticOperator, Switch, SwitchCase,
    };
    use bson::{bson, doc};

    test_codegen_expression!(
        one_case,
        expected = Ok(bson!({"$switch":
            {
                "branches": vec![doc!{
                    "case": {"$lt": [{ "$literal": 10}, { "$literal": 20}]},
                    "then": {"$literal": "first"}
                }],
                "default": {"$literal": "else"}
            }
        })),
        input = Switch(Switch {
            branches: vec![SwitchCase {
                case: Box::new(MqlSemanticOperator(MqlSemanticOperator {
                    op: Lt,
                    args: vec![Literal(Integer(10)), Literal(Integer(20))],
                })),
                then: Box::new(Literal(String("first".to_string())))
            }],
            default: Box::new(Literal(String("else".to_string())))
        })
    );

    test_codegen_expression!(
        multiple_cases,
        expected = Ok(bson!({"$switch":
            {
                "branches": vec![doc!{
                    "case": {"$lt": [{ "$literal": 10}, { "$literal": 20}]},
                    "then": {"$literal": "first"}
                },
                doc!{
                    "case": {"$gt": [{ "$literal": 1}, { "$literal": 2}]},
                    "then": {"$literal": "second"}
                },
                doc!{
                    "case": {"$eq": [{ "$literal": 1}, { "$literal": 2}]},
                    "then": {"$literal": "third"}
                }],
                "default": {"$literal": "else"}
            }
        })),
        input = Switch(Switch {
            branches: vec![
                SwitchCase {
                    case: Box::new(MqlSemanticOperator(MqlSemanticOperator {
                        op: Lt,
                        args: vec![Literal(Integer(10)), Literal(Integer(20))],
                    })),
                    then: Box::new(Literal(String("first".to_string())))
                },
                SwitchCase {
                    case: Box::new(MqlSemanticOperator(MqlSemanticOperator {
                        op: Gt,
                        args: vec![Literal(Integer(1)), Literal(Integer(2))],
                    })),
                    then: Box::new(Literal(String("second".to_string())))
                },
                SwitchCase {
                    case: Box::new(MqlSemanticOperator(MqlSemanticOperator {
                        op: Eq,
                        args: vec![Literal(Integer(1)), Literal(Integer(2))],
                    })),
                    then: Box::new(Literal(String("third".to_string())))
                }
            ],
            default: Box::new(Literal(String("else".to_string())))
        })
    );
}

mod literal {
    use crate::air::{Expression::*, LiteralValue::*};
    use bson::{Bson, bson};

    test_codegen_expression!(
        null,
        expected = Ok(bson!({ "$literal": Bson::Null })),
        input = Literal(Null)
    );

    test_codegen_expression!(
        boolean,
        expected = Ok(bson!({ "$literal": Bson::Boolean(true)})),
        input = Literal(Boolean(true))
    );

    test_codegen_expression!(
        string,
        expected = Ok(bson!({ "$literal": Bson::String("foo".to_string())})),
        input = Literal(String("foo".to_string()))
    );

    test_codegen_expression!(
        int,
        expected = Ok(bson!({ "$literal": 1_i32})),
        input = Literal(Integer(1))
    );

    test_codegen_expression!(
        long,
        expected = Ok(bson!({ "$literal": 2_i64})),
        input = Literal(Long(2))
    );

    test_codegen_expression!(
        double,
        expected = Ok(bson!({ "$literal": 3.0})),
        input = Literal(Double(3.0))
    );

    test_codegen_expression!(
        regex,
        expected = Ok(bson!({ "$literal": Bson::RegularExpression(bson::Regex {
            pattern: "pattern".to_string(),
            options: "options".to_string()
        })})),
        input = Literal(RegularExpression(bson::Regex {
            pattern: "pattern".to_string(),
            options: "options".to_string()
        }))
    );

    test_codegen_expression!(
        javascript,
        expected = Ok(bson!({ "$literal": Bson::JavaScriptCode("js".to_string())})),
        input = Literal(JavaScriptCode("js".to_string()))
    );

    test_codegen_expression!(
        javascript_with_scope,
        expected = Ok(
            bson!({ "$literal": Bson::JavaScriptCodeWithScope(bson::JavaScriptCodeWithScope {
                code: "js".to_string(),
                scope: bson::doc! {}
            })})
        ),
        input = Literal(JavaScriptCodeWithScope(bson::JavaScriptCodeWithScope {
            code: "js".to_string(),
            scope: bson::doc! {}
        }))
    );

    test_codegen_expression!(
        timestamp,
        expected = Ok(bson!({ "$literal": Bson::Timestamp(bson::Timestamp {
            time: 1,
            increment: 2
        })})),
        input = Literal(Timestamp(bson::Timestamp {
            time: 1,
            increment: 2
        }))
    );

    test_codegen_expression!(
        bin_data,
        expected = Ok(bson!({ "$literal": Bson::Binary(bson::Binary {
            subtype: bson::spec::BinarySubtype::Uuid,
            bytes: vec![]
        })})),
        input = Literal(Binary(bson::Binary {
            subtype: bson::spec::BinarySubtype::Uuid,
            bytes: vec![]
        }))
    );

    test_codegen_expression!(
        oid,
        expected = Ok(bson!({ "$literal": Bson::ObjectId(
            bson::oid::ObjectId::parse_str("000000000000000000000000").unwrap()
        )})),
        input = Literal(ObjectId(
            bson::oid::ObjectId::parse_str("000000000000000000000000").unwrap()
        ))
    );

    test_codegen_expression!(
        minkey,
        expected = Ok(bson!({ "$literal": Bson::MinKey})),
        input = Literal(MinKey)
    );

    test_codegen_expression!(
        maxkey,
        expected = Ok(bson!({ "$literal": Bson::MaxKey})),
        input = Literal(MaxKey)
    );

    test_codegen_expression!(
        undefined,
        expected = Ok(bson!({ "$literal": Bson::Undefined})),
        input = Literal(Undefined)
    );

    test_codegen_expression!(
        symbol,
        expected = Ok(bson!({ "$literal": Bson::Symbol("test".to_string())})),
        input = Literal(Symbol("test".to_string()))
    );

    test_codegen_expression!(
        datetime,
        expected = Ok(bson!({ "$literal": Bson::DateTime(bson::DateTime::MAX)})),
        input = Literal(DateTime(bson::DateTime::MAX))
    );

    test_codegen_expression!(
        decimal128,
        expected = Ok(bson!({ "$literal": Bson::Decimal128(
            bson::Decimal128::from_bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        )})),
        input = Literal(Decimal128(bson::Decimal128::from_bytes([
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
        ])))
    );
}

mod trim {

    use crate::air::{Expression::*, LiteralValue::*, Trim, TrimOperator};
    use bson::bson;

    test_codegen_expression!(
        trim,
        expected =
            Ok(bson!({ "$trim": { "input": {"$literal": "foo"}, "chars": {"$literal": null }}})),
        input = Trim(Trim {
            op: TrimOperator::Trim,
            input: Box::new(Literal(String("foo".to_string()))),
            chars: Box::new(Literal(Null)),
        })
    );

    test_codegen_expression!(
        ltrim,
        expected =
            Ok(bson!({ "$ltrim": {"input": { "$literal": "foo"}, "chars": {"$literal": null }}})),
        input = Trim(Trim {
            op: TrimOperator::LTrim,
            input: Box::new(Literal(String("foo".to_string()))),
            chars: Box::new(Literal(Null)),
        })
    );

    test_codegen_expression!(
        rtrim,
        expected =
            Ok(bson!({ "$rtrim": {"input": { "$literal": "foo"}, "chars": {"$literal": null }}})),
        input = Trim(Trim {
            op: TrimOperator::RTrim,
            input: Box::new(Literal(String("foo".to_string()))),
            chars: Box::new(Literal(Null)),
        })
    );
}

mod mql_semantic_operator {
    use crate::air::{self, Expression::*, LiteralValue::*, MqlOperator::*, MqlSemanticOperator};
    use bson::bson;

    test_codegen_expression!(
        concat,
        expected = Ok(bson!({ "$concat": [{ "$literal": "foo"}, { "$literal": "bar"}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Concat,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(String("bar".to_string()))
            ],
        })
    );

    test_codegen_expression!(
        add,
        expected = Ok(bson!({ "$add": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Add,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        subtract,
        expected = Ok(bson!({ "$subtract": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Subtract,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        multiply,
        expected = Ok(bson!({ "$multiply": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Multiply,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        divide,
        expected = Ok(bson!({ "$divide": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Divide,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        lt,
        expected = Ok(bson!({ "$lt": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Lt,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        lte,
        expected = Ok(bson!({ "$lte": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Lte,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        ne,
        expected = Ok(bson!({ "$ne": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Ne,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        eq,
        expected = Ok(bson!({ "$eq": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Eq,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        gt,
        expected = Ok(bson!({ "$gt": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Gt,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        gte,
        expected = Ok(bson!({ "$gte": [{ "$literal": 1}, { "$literal": 2}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Gte,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        between,
        expected =
            Ok(bson!({ "$mqlBetween": [{ "$literal": 1}, { "$literal": 2}, { "$literal": 3}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Between,
            args: vec![
                Literal(Integer(1)),
                Literal(Integer(2)),
                Literal(Integer(3))
            ],
        })
    );

    test_codegen_expression!(
        not,
        expected = Ok(bson!({ "$not": [{ "$literal": false}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Not,
            args: vec![Literal(Boolean(false))],
        })
    );

    test_codegen_expression!(
        and,
        expected = Ok(bson!({ "$and": [{ "$literal": true}, { "$literal": false}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: And,
            args: vec![Literal(Boolean(true)), Literal(Boolean(false))],
        })
    );

    test_codegen_expression!(
        or,
        expected = Ok(bson!({ "$or": [{ "$literal": true}, { "$literal": false}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Or,
            args: vec![Literal(Boolean(true)), Literal(Boolean(false))],
        })
    );

    test_codegen_expression!(
        slice,
        expected = Ok(
            bson!({ "$slice": [[{"$literal": 1}, {"$literal": 2}, {"$literal": 3}], {"$literal": 1}, { "$literal": 2}]})
        ),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Slice,
            args: vec![
                air::Expression::Array(vec![
                    Literal(Integer(1)),
                    Literal(Integer(2)),
                    Literal(Integer(3))
                ]),
                Literal(Integer(1)),
                Literal(Integer(2))
            ],
        })
    );

    test_codegen_expression!(
        size,
        expected = Ok(bson!({ "$size": [[{"$literal": 1}, {"$literal": 2}, {"$literal": 3}]]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Size,
            args: vec![air::Expression::Array(vec![
                Literal(Integer(1)),
                Literal(Integer(2)),
                Literal(Integer(3))
            ])],
        })
    );

    test_codegen_expression!(
        index_of_cp,
        expected = Ok(
            bson!({ "$indexOfCP": [{ "$literal": "foo"}, { "$literal": "bar"}, { "$literal": 1}, { "$literal": 2}]})
        ),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: IndexOfCP,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(String("bar".to_string())),
                Literal(Integer(1)),
                Literal(Integer(2)),
            ],
        })
    );

    test_codegen_expression!(
        index_of_bytes,
        expected = Ok(
            bson!({ "$indexOfBytes": [{ "$literal": "foo"}, { "$literal": "bar"}, { "$literal": 1}, { "$literal": 2}]})
        ),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: IndexOfBytes,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(String("bar".to_string())),
                Literal(Integer(1)),
                Literal(Integer(2)),
            ],
        })
    );

    test_codegen_expression!(
        str_len_cp,
        expected = Ok(bson!({ "$strLenCP": [{ "$literal": "foo"}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: StrLenCP,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        str_len_bytes,
        expected = Ok(bson!({ "$strLenBytes": [{ "$literal": "foo"}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: StrLenBytes,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        abs,
        expected = Ok(bson!({ "$abs": [{"$literal": -1}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Abs,
            args: vec![Literal(Integer(-1)),],
        })
    );

    test_codegen_expression!(
        ceil,
        expected = Ok(bson!({ "$ceil": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Ceil,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        cos,
        expected = Ok(bson!({ "$cos": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Cos,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        sin,
        expected = Ok(bson!({ "$sin": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Sin,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        tan,
        expected = Ok(bson!({ "$tan": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Tan,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        degrees_to_radians,
        expected = Ok(bson!({ "$degreesToRadians": [{"$literal": 180.0}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: DegreesToRadians,
            args: vec![Literal(Double(180.0)),],
        })
    );

    test_codegen_expression!(
        radians_to_degrees,
        expected = Ok(bson!({ "$radiansToDegrees": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: RadiansToDegrees,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        floor,
        expected = Ok(bson!({ "$floor": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Floor,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        log,
        expected = Ok(bson!({ "$log": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Log,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        mod_op,
        expected = Ok(bson!({ "$mod": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Mod,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        pow,
        expected = Ok(bson!({ "$pow": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Pow,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        round,
        expected = Ok(bson!({ "$round": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Round,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        sqrt,
        expected = Ok(bson!({ "$sqrt": [{"$literal": 3.5}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Sqrt,
            args: vec![Literal(Double(3.5)),],
        })
    );

    test_codegen_expression!(
        avg,
        expected = Ok(bson!({ "$avg": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Avg,
            args: vec![FieldRef("foo".to_string().into()),],
        })
    );

    test_codegen_expression!(
        max,
        expected = Ok(bson!({ "$max": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Max,
            args: vec![FieldRef("foo".to_string().into()),],
        })
    );

    test_codegen_expression!(
        min,
        expected = Ok(bson!({ "$min": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Min,
            args: vec![FieldRef("foo".to_string().into()),],
        })
    );

    test_codegen_expression!(
        sum,
        expected = Ok(bson!({ "$sum": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Sum,
            args: vec![FieldRef("foo".to_string().into()),],
        })
    );

    test_codegen_expression!(
        stddev_pop,
        expected = Ok(bson!({ "$stdDevPop": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: StddevPop,
            args: vec![FieldRef("foo".to_string().into()),],
        })
    );

    test_codegen_expression!(
        stddev_samp,
        expected = Ok(bson!({ "$stdDevSamp": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: StddevSamp,
            args: vec![FieldRef("foo".to_string().into()),],
        })
    );

    test_codegen_expression!(
        substr_cp,
        expected =
            Ok(bson!({ "$substrCP": [{ "$literal": "foo"}, { "$literal": 1 }, { "$literal": 2 }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: SubstrCP,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(Integer(1)),
                Literal(Integer(2))
            ],
        })
    );

    test_codegen_expression!(
        replace_all,
        expected = Ok(bson!({ "$replaceAll": {
            "input": { "$literal": "foo"},
            "find": { "$literal": "o" },
            "replacement": { "$literal": "f" }
        }})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: ReplaceAll,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(String("o".to_string())),
                Literal(String("f".to_string())),
            ],
        })
    );

    test_codegen_expression!(
        substr_bytes,
        expected = Ok(
            bson!({ "$substrBytes": [{ "$literal": "foo"}, { "$literal": 1 }, { "$literal": 2 }]})
        ),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: SubstrBytes,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(Integer(1)),
                Literal(Integer(2))
            ],
        })
    );

    test_codegen_expression!(
        to_upper,
        expected = Ok(bson!({ "$toUpper": [{ "$literal": "foo"}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: ToUpper,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        to_lower,
        expected = Ok(bson!({ "$toLower": [{ "$literal": "foo"}]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: ToLower,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        split,
        expected = Ok(bson!({ "$split": [{ "$literal": "foo" }, { "$literal": "o" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Split,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(String("o".to_string()))
            ],
        })
    );

    test_codegen_expression!(
        year,
        expected = Ok(bson!({ "$year": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Year,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        month,
        expected = Ok(bson!({ "$month": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Month,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        day_of_month,
        expected = Ok(bson!({ "$dayOfMonth": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: DayOfMonth,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        hour,
        expected = Ok(bson!({ "$hour": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Hour,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        minute,
        expected = Ok(bson!({ "$minute": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Minute,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        second,
        expected = Ok(bson!({ "$second": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Second,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        week,
        expected = Ok(bson!({ "$week": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Week,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        day_of_year,
        expected = Ok(bson!({ "$dayOfYear": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: DayOfYear,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        iso_week,
        expected = Ok(bson!({ "$isoWeek": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: IsoWeek,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        iso_day_of_week,
        expected = Ok(bson!({ "$isoDayOfWeek": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: IsoDayOfWeek,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        date_add,
        expected = Ok(bson!({ "$dateAdd": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: DateAdd,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        date_diff,
        expected = Ok(bson!({ "$dateDiff": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: DateDiff,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        date_trunc,
        expected = Ok(bson!({ "$dateTrunc": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: DateTrunc,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        merge_object,
        expected = Ok(bson!({ "$mergeObjects": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: MergeObjects,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        object_to_array,
        expected = Ok(bson!({ "$objectToArray": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: ObjectToArray,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        is_number,
        expected = Ok(bson!({ "$isNumber": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: IsNumber,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        is_array,
        expected = Ok(bson!({ "$isArray": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: IsArray,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        if_null,
        expected = Ok(bson!({ "$ifNull": [{ "$literal": "foo" }, { "$literal": "bar" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: IfNull,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(String("bar".to_string())),
            ],
        })
    );

    test_codegen_expression!(
        type_op,
        expected = Ok(bson!({ "$type": [{ "$literal": "foo" }]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Type,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        array_elem_at,
        expected = Ok(
            bson!({ "$arrayElemAt": [[{ "$literal": "foo" }, { "$literal": "bar" }], { "$literal": 1} ]})
        ),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: ElemAt,
            args: vec![
                air::Expression::Array(vec![
                    Literal(String("foo".to_string())),
                    Literal(String("bar".to_string()))
                ]),
                Literal(Integer(1)),
            ],
        })
    );

    test_codegen_expression!(
        in_op,
        expected = Ok(bson!({ "$in": [{ "$literal": 1}, [{ "$literal": 1 }, { "$literal": 2 }]]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: In,
            args: vec![
                Literal(Integer(1)),
                air::Expression::Array(vec![Literal(Integer(1)), Literal(Integer(2))]),
            ],
        })
    );

    test_codegen_expression!(
        not_in_op,
        expected = Ok(
            bson!({ "$not": [{ "$in": [{ "$literal": 1}, [{ "$literal": 1 }, { "$literal": 2 }]]}]})
        ),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: NotIn,
            args: vec![
                Literal(Integer(1)),
                air::Expression::Array(vec![Literal(Integer(1)), Literal(Integer(2))]),
            ],
        })
    );

    test_codegen_expression!(
        first,
        expected = Ok(bson!({ "$first": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: First,
            args: vec![FieldRef("foo".to_string().into())],
        })
    );

    test_codegen_expression!(
        last,
        expected = Ok(bson!({ "$last": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Last,
            args: vec![FieldRef("foo".to_string().into())],
        })
    );

    test_codegen_expression!(
        all_elements_true,
        expected = Ok(bson!({ "$allElementsTrue": ["$foo"]})),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: AllElementsTrue,
            args: vec![FieldRef("foo".to_string().into())],
        })
    );

    test_codegen_expression!(
        cond,
        expected = Ok(
            bson!({ "$cond": [{ "$literal": false }, { "$literal": "foo" }, { "$literal": "bar"} ]})
        ),
        input = MqlSemanticOperator(MqlSemanticOperator {
            op: Cond,
            args: vec![
                Literal(Boolean(false)),
                Literal(String("foo".to_string())),
                Literal(String("bar".to_string())),
            ],
        })
    );
}

mod sql_semantic_operator {
    use crate::air::{self, Expression::*, LiteralValue::*, SqlOperator::*, SqlSemanticOperator};
    use bson::bson;

    test_codegen_expression!(
        pos,
        expected = Ok(bson! ({ "$sqlPos": [{ "$literal": 2}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Pos,
            args: vec![Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        neg,
        expected = Ok(bson! ({ "$sqlNeg": [{ "$literal": 1}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Neg,
            args: vec![Literal(Integer(1))],
        })
    );

    test_codegen_expression!(
        lt,
        expected = Ok(bson!({ "$sqlLt": [{ "$literal": 1}, { "$literal": 2}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Lt,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        lte,
        expected = Ok(bson!({ "$sqlLte": [{ "$literal": 1}, { "$literal": 2}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Lte,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        ne,
        expected = Ok(bson!({ "$sqlNe": [{ "$literal": 1}, { "$literal": 2}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Ne,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        eq,
        expected = Ok(bson!({ "$sqlEq": [{ "$literal": 1}, { "$literal": 2}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Eq,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        gt,
        expected = Ok(bson!({ "$sqlGt": [{ "$literal": 1}, { "$literal": 2}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Gt,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );
    test_codegen_expression!(
        gte,
        expected = Ok(bson!({ "$sqlGte": [{ "$literal": 1}, { "$literal": 2}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Gte,
            args: vec![Literal(Integer(1)), Literal(Integer(2))],
        })
    );

    test_codegen_expression!(
        between,
        expected =
            Ok(bson!({ "$sqlBetween": [[{"$literal": 1}, {"$literal": 2}, {"$literal": 3}]]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Between,
            args: vec![air::Expression::Array(vec![
                Literal(Integer(1)),
                Literal(Integer(2)),
                Literal(Integer(3))
            ])],
        })
    );

    test_codegen_expression!(
        nullif_expr,
        expected = Ok(bson!({ "$nullIf": [{ "$literal": true}, { "$literal": false}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: NullIf,
            args: vec![Literal(Boolean(true)), Literal(Boolean(false))],
        })
    );

    test_codegen_expression!(
        coalesce_expr,
        expected = Ok(bson!({ "$coalesce": [{ "$literal": 1}, { "$literal": 2}, {"$literal": 3}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Coalesce,
            args: vec![
                Literal(Integer(1)),
                Literal(Integer(2)),
                Literal(Integer(3))
            ],
        })
    );

    test_codegen_expression!(
        not,
        expected = Ok(bson!({ "$sqlNot": [{ "$literal": false}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Not,
            args: vec![Literal(Boolean(false))],
        })
    );

    test_codegen_expression!(
        and,
        expected = Ok(bson!({ "$sqlAnd": [{ "$literal": true}, { "$literal": false}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: And,
            args: vec![Literal(Boolean(true)), Literal(Boolean(false))],
        })
    );
    test_codegen_expression!(
        or,
        expected = Ok(bson!({ "$sqlOr": [{ "$literal": true}, { "$literal": false}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Or,
            args: vec![Literal(Boolean(true)), Literal(Boolean(false))],
        })
    );
    test_codegen_expression!(
        slice,
        expected = Ok(
            bson!({ "$sqlSlice": [[{"$literal": 1}, {"$literal": 2}, {"$literal": 3}], {"$literal": 1}, { "$literal": 2}]})
        ),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Slice,
            args: vec![
                air::Expression::Array(vec![
                    Literal(Integer(1)),
                    Literal(Integer(2)),
                    Literal(Integer(3))
                ]),
                Literal(Integer(1)),
                Literal(Integer(2))
            ],
        })
    );
    test_codegen_expression!(
        size,
        expected = Ok(bson!({ "$sqlSize": [{"$literal": 1}, {"$literal": 2}, {"$literal": 3}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Size,
            args: vec![air::Expression::Array(vec![
                Literal(Integer(1)),
                Literal(Integer(2)),
                Literal(Integer(3))
            ])],
        })
    );
    test_codegen_expression!(
        index_of_cp,
        expected = Ok(
            bson!({ "$sqlIndexOfCP": [{ "$literal": "foo"}, { "$literal": "bar"}, { "$literal": 1}, { "$literal": 2}]})
        ),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: IndexOfCP,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(String("bar".to_string())),
                Literal(Integer(1)),
                Literal(Integer(2)),
            ],
        })
    );

    test_codegen_expression!(
        str_len_cp,
        expected = Ok(bson!({ "$sqlStrLenCP": { "$literal": "foo"}})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: StrLenCP,
            args: vec![Literal(String("foo".to_string())),],
        })
    );
    test_codegen_expression!(
        str_len_bytes,
        expected = Ok(bson!({ "$sqlStrLenBytes": { "$literal": "foo"}})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: StrLenBytes,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        bit_length,
        expected = Ok(bson!({ "$sqlBitLength": [{ "$literal": "foo"}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: BitLength,
            args: vec![Literal(String("foo".to_string())),],
        })
    );
    test_codegen_expression!(
        cos,
        expected = Ok(bson!({ "$sqlCos": [{"$literal": 3.5}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Cos,
            args: vec![Literal(Double(3.5)),],
        })
    );
    test_codegen_expression!(
        log,
        expected = Ok(bson!({ "$sqlLog": [{"$literal": 3.5}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Log,
            args: vec![Literal(Double(3.5)),],
        })
    );
    test_codegen_expression!(
        mod_op,
        expected = Ok(bson!({ "$sqlMod": [{"$literal": 3.5}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Mod,
            args: vec![Literal(Double(3.5)),],
        })
    );
    test_codegen_expression!(
        round,
        expected = Ok(bson!({ "$sqlRound": [{"$literal": 3.5}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Round,
            args: vec![Literal(Double(3.5)),],
        })
    );
    test_codegen_expression!(
        sin,
        expected = Ok(bson!({ "$sqlSin": [{"$literal": 3.5}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Sin,
            args: vec![Literal(Double(3.5)),],
        })
    );
    test_codegen_expression!(
        sqrt,
        expected = Ok(bson!({ "$sqlSqrt": [{"$literal": 3.5}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Sqrt,
            args: vec![Literal(Double(3.5)),],
        })
    );
    test_codegen_expression!(
        tan,
        expected = Ok(bson!({ "$sqlTan": [{"$literal": 3.5}]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Tan,
            args: vec![Literal(Double(3.5)),],
        })
    );
    test_codegen_expression!(
        substr_cp,
        expected = Ok(
            bson!({ "$sqlSubstrCP": [{ "$literal": "foo"}, { "$literal": 1 }, { "$literal": 2 }]})
        ),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: SubstrCP,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(Integer(1)),
                Literal(Integer(2))
            ],
        })
    );
    test_codegen_expression!(
        to_upper,
        expected = Ok(bson!({ "$sqlToUpper": { "$literal": "foo"}})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: ToUpper,
            args: vec![Literal(String("foo".to_string())),],
        })
    );

    test_codegen_expression!(
        to_lower,
        expected = Ok(bson!({ "$sqlToLower": { "$literal": "foo"}})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: ToLower,
            args: vec![Literal(String("foo".to_string())),],
        })
    );
    test_codegen_expression!(
        split,
        expected = Ok(bson!({ "$sqlSplit": [{ "$literal": "foo" }, { "$literal": "o" }]})),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: Split,
            args: vec![
                Literal(String("foo".to_string())),
                Literal(String("o".to_string()))
            ],
        })
    );
    test_codegen_expression!(
        current_timestamp,
        expected = Ok(bson!("$$NOW")),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: CurrentTimestamp,
            args: vec![],
        })
    );

    test_codegen_expression!(
        in_op,
        expected = Ok(
            bson!({ "$in": [{ "$literal": 1 }, [{ "$literal": 1 }, { "$literal": 2 }, { "$literal": 3 }]] })
        ),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: In,
            args: vec![
                Literal(Integer(1)),
                air::Expression::Array(vec![
                    Literal(Integer(1)),
                    Literal(Integer(2)),
                    Literal(Integer(3)),
                ]),
            ],
        })
    );

    // NotIn in an expression context ($project) must emit { "$not": [{ "$in": [...] }] }.
    // $nin is a match-language-only operator and is rejected by the server in $project.
    test_codegen_expression!(
        not_in_op,
        expected = Ok(
            bson!({ "$not": [{ "$in": [{ "$literal": 1 }, [{ "$literal": 1 }, { "$literal": 2 }, { "$literal": 3 }]] }] })
        ),
        input = SqlSemanticOperator(SqlSemanticOperator {
            op: NotIn,
            args: vec![
                Literal(Integer(1)),
                air::Expression::Array(vec![
                    Literal(Integer(1)),
                    Literal(Integer(2)),
                    Literal(Integer(3)),
                ]),
            ],
        })
    );
}

mod document {
    use crate::{
        air::{self, Expression::*, LiteralValue::*},
        unchecked_unique_linked_hash_map,
    };
    use bson::bson;

    test_codegen_expression!(
        empty,
        expected = Ok(bson!({"$literal": {}})),
        input = air::Expression::Document(unchecked_unique_linked_hash_map! {})
    );
    test_codegen_expression!(
        non_empty,
        expected = Ok(bson!({"foo": {"$literal": 1}})),
        input = air::Expression::Document(
            unchecked_unique_linked_hash_map! {"foo".to_string() => Literal(Integer(1))}
        )
    );
    test_codegen_expression!(
        nested,
        expected = Ok(bson!({"foo": {"$literal": 1}, "bar": {"baz": {"$literal": 2}}})),
        input = air::Expression::Document(unchecked_unique_linked_hash_map! {
            "foo".to_string() => Literal(Integer(1)),
            "bar".to_string() => air::Expression::Document(unchecked_unique_linked_hash_map!{
                "baz".to_string() => Literal(Integer(2))
            }),
        })
    );
}

mod array {
    use crate::air::{self, Expression::*, LiteralValue::*};
    use bson::bson;

    test_codegen_expression!(
        empty,
        expected = Ok(bson!([])),
        input = air::Expression::Array(vec![])
    );

    test_codegen_expression!(
        non_empty,
        expected = Ok(bson!([{"$literal": "abc"}])),
        input = air::Expression::Array(vec![Literal(String("abc".to_string()))])
    );

    test_codegen_expression!(
        nested,
        expected = Ok(bson!([{ "$literal": null }, [{ "$literal": null }]])),
        input = air::Expression::Array(vec![
            Literal(Null),
            air::Expression::Array(vec![Literal(Null)])
        ])
    );
}

mod variable {
    use crate::air::Expression::*;
    use bson::{Bson, bson};

    test_codegen_expression!(
        simple,
        expected = Ok(bson!(Bson::String("$$foo".to_string()))),
        input = Variable("foo".to_string().into())
    );

    test_codegen_expression!(
        nested,
        expected = Ok(bson!(Bson::String("$$x.y.z".to_string()))),
        input = Variable("x.y.z".to_string().into())
    );
}

mod field_ref {
    use crate::air::Expression::FieldRef;
    use bson::{Bson, bson};

    test_codegen_expression!(
        no_parent,
        expected = Ok(bson!(Bson::String("$foo".to_string()))),
        input = FieldRef("foo".to_string().into())
    );
    test_codegen_expression!(
        parent,
        expected = Ok(bson!(Bson::String("$bar.foo".to_string()))),
        input = FieldRef("bar.foo".to_string().into())
    );

    test_codegen_expression!(
        grandparent,
        expected = Ok(bson!(Bson::String("$baz.bar.foo".to_string()))),
        input = FieldRef("baz.bar.foo".to_string().into())
    );
}

mod like {
    use crate::air::{self, Expression};
    use bson::bson;

    test_codegen_expression!(
        with_escape,
        expected = Ok(bson!({"$like": {
            "input": "$input",
            "pattern": "$pattern",
            "escape": "'",
        }})),
        input = Expression::Like(air::Like {
            expr: Box::new(Expression::FieldRef("input".to_string().into())),
            pattern: Box::new(Expression::FieldRef("pattern".to_string().into())),
            escape: Some('\''),
        })
    );

    test_codegen_expression!(
        without_escape,
        expected = Ok(bson!({"$like": {
            "input": "$input",
            "pattern": "$pattern",
        }})),
        input = Expression::Like(air::Like {
            expr: Box::new(Expression::FieldRef("input".to_string().into())),
            pattern: Box::new(Expression::FieldRef("pattern".to_string().into())),
            escape: None,
        })
    );
}

mod is {
    use crate::air::{Expression::*, Is, Type, TypeOrMissing};
    use bson::bson;

    test_codegen_expression!(
        target_type_missing,
        expected = Ok(bson!({"$sqlIs": ["$x", {"$literal": "missing"}]})),
        input = Is(Is {
            expr: Box::new(FieldRef("x".to_string().into())),
            target_type: TypeOrMissing::Missing,
        })
    );

    test_codegen_expression!(
        target_type_number,
        expected = Ok(bson!({"$sqlIs": ["$x", {"$literal": "number"}]})),
        input = Is(Is {
            expr: Box::new(FieldRef("x".to_string().into())),
            target_type: TypeOrMissing::Number,
        })
    );

    test_codegen_expression!(
        target_type_type,
        expected = Ok(bson!({"$sqlIs": ["$x", {"$literal": "object"}]})),
        input = Is(Is {
            expr: Box::new(FieldRef("x".to_string().into())),
            target_type: TypeOrMissing::Type(Type::Document),
        })
    );
}

mod get_field {
    use crate::{
        air::{
            self,
            Expression::{Document, FieldRef, GetField, Literal, MqlSemanticOperator},
            LiteralValue, MqlOperator,
        },
        unchecked_unique_linked_hash_map,
    };
    use bson::bson;

    test_codegen_expression!(
        basic_string_literal,
        expected = Ok(bson!({"$getField": {"field": "x", "input": {"x": {"$literal": 42}}}})),
        input = GetField(air::GetField {
            field: Literal(LiteralValue::String("x".to_string())).into(),
            input: Document(unchecked_unique_linked_hash_map! {
                "x".to_string() => Literal(LiteralValue::Integer(42)),
            })
            .into(),
        })
    );

    test_codegen_expression!(
        string_literal_with_dollar_sign,
        expected = Ok(
            bson!({"$getField": {"field": { "$literal": "$x"}, "input": {"$x": {"$literal": 42}}}})
        ),
        input = GetField(air::GetField {
            field: Literal(LiteralValue::String("$x".to_string())).into(),
            input: Document(unchecked_unique_linked_hash_map! {
                "$x".to_string() => Literal(LiteralValue::Integer(42)),
            })
            .into(),
        })
    );

    test_codegen_expression!(
        complex_field_expr,
        expected = Ok(
            bson!({"$getField": {"field": { "$concat": ["$a", "$b"]}, "input": {"$x": {"$literal": 42}}}})
        ),
        input = GetField(air::GetField {
            field: MqlSemanticOperator(air::MqlSemanticOperator {
                op: MqlOperator::Concat,
                args: vec![
                    FieldRef("a".to_string().into()),
                    FieldRef("b".to_string().into())
                ],
            })
            .into(),
            input: Document(unchecked_unique_linked_hash_map! {
                "$x".to_string() => Literal(LiteralValue::Integer(42)),
            })
            .into(),
        })
    );
}

mod set_field {
    use crate::{
        air::{Expression::*, SetField},
        util::ROOT,
    };
    use bson::bson;

    test_codegen_expression!(
        simple,
        expected = Ok(bson!({"$setField": {"field": "", "input": "$$ROOT", "value": "$__bot"}})),
        input = SetField(SetField {
            field: "".into(),
            input: Box::new(ROOT.clone()),
            value: Box::new(FieldRef("__bot".to_string().into()))
        })
    );

    test_codegen_expression!(
        use_literal_when_needed,
        expected = Ok(
            bson!({"$setField": {"field": {"$literal": "$x_val"}, "input": "$$ROOT", "value": "$x"}})
        ),
        input = SetField(SetField {
            field: "$x_val".into(),
            input: Box::new(ROOT.clone()),
            value: Box::new(FieldRef("x".to_string().into()))
        })
    );
}

mod unset_field {
    use crate::air::{Expression::*, UnsetField};
    use bson::bson;

    test_codegen_expression!(
        simple,
        expected = Ok(bson!({"$unsetField": {"field": "__bot", "input": "$doc"}})),
        input = UnsetField(UnsetField {
            field: "__bot".into(),
            input: Box::new(FieldRef("doc".to_string().into()))
        })
    );

    test_codegen_expression!(
        use_literal_when_needed,
        expected = Ok(bson!({"$unsetField": {"field": {"$literal": "$x"}, "input": "$doc"}})),
        input = UnsetField(UnsetField {
            field: "$x".into(),
            input: Box::new(FieldRef("doc".to_string().into()))
        })
    );
}

mod sql_convert {
    use crate::{
        air::{Expression::*, LiteralValue, SqlConvert, SqlConvertTargetType},
        unchecked_unique_linked_hash_map,
    };
    use bson::bson;

    test_codegen_expression!(
        array,
        expected = Ok(bson!({ "$sqlConvert": {
          "input": [],
          "to": "array",
          "onNull": {"$literal": null},
          "onError": {"$literal": null}
        }})),
        input = SqlConvert(SqlConvert {
            input: Box::new(Array(vec![])),
            to: SqlConvertTargetType::Array,
            on_null: Box::new(Literal(LiteralValue::Null)),
            on_error: Box::new(Literal(LiteralValue::Null)),
        })
    );
    test_codegen_expression!(
        document,
        expected = Ok(bson!({ "$sqlConvert": {
          "input": {"$literal":{}},
          "to": "object",
          "onNull": {"$literal": null},
          "onError": {"$literal": null}
        }})),
        input = SqlConvert(SqlConvert {
            input: Box::new(Document(unchecked_unique_linked_hash_map! {})),
            to: SqlConvertTargetType::Document,
            on_null: Box::new(Literal(LiteralValue::Null)),
            on_error: Box::new(Literal(LiteralValue::Null)),
        })
    );
}

mod sql_divide {
    use crate::air::{Expression::*, LiteralValue, SqlDivide};

    test_codegen_expression!(
        simple,
        expected = Ok(
            bson::bson! ({"$sqlDivide": {"dividend": {"$literal": 1}, "divisor": {"$literal": 2}, "onError": {"$literal": null}}})
        ),
        input = SqlDivide(SqlDivide {
            dividend: Box::new(Literal(LiteralValue::Integer(1))),
            divisor: Box::new(Literal(LiteralValue::Integer(2))),
            on_error: Box::new(Literal(LiteralValue::Null)),
        })
    );
}

mod convert {
    use crate::{
        air::{Convert, Expression, LiteralValue::*, Type},
        codegen,
    };
    use bson::bson;

    macro_rules! test_codegen_working_convert {
        ($test_name:ident, expected = $expected_ty_str:expr, input = $input:expr) => {
        test_codegen_expression!(
            $test_name,
            expected = Ok(bson!({
                "$convert": {
                    "input": {"$literal": "foo"},
                    "to":
                        if $expected_ty_str == "string" {
                            bson!({
                                "$cond": [
                                    {"$eq": [{"$type": {"$literal": "foo"}}, "binData"]},
                                    "null",
                                    $expected_ty_str
                                ]
                            })
                        } else {
                            bson!($expected_ty_str)
                        },
                    "onError": {"$literal": null},
                    "onNull": {"$literal": null},
                }
            })),
            input = Expression::Convert(Convert {
                    input: Expression::Literal(String("foo".to_string())).into(),
                    to: $input,
                    on_null: Expression::Literal(Null).into(),
                    on_error: Expression::Literal(Null).into(),
                })
            );
        };
    }

    test_codegen_expression!(
        convert_array,
        expected = Err(codegen::Error::ConvertToArray),
        input = Expression::Convert(Convert {
            input: Expression::Literal(String("foo".to_string())).into(),
            to: Type::Array,
            on_null: Expression::Literal(Null).into(),
            on_error: Expression::Literal(Null).into(),
        })
    );

    test_codegen_expression!(
        convert_document,
        expected = Err(codegen::Error::ConvertToDocument),
        input = Expression::Convert(Convert {
            input: Expression::Literal(String("foo".to_string())).into(),
            to: Type::Document,
            on_null: Expression::Literal(Null).into(),
            on_error: Expression::Literal(Null).into(),
        })
    );

    test_codegen_working_convert!(
        convert_bin_data,
        expected = "binData",
        input = Type::BinData
    );

    test_codegen_working_convert!(convert_date, expected = "date", input = Type::Datetime);

    test_codegen_working_convert!(
        convert_db_pointer,
        expected = "dbPointer",
        input = Type::DbPointer
    );

    test_codegen_working_convert!(
        convert_decimal,
        expected = "decimal",
        input = Type::Decimal128
    );

    test_codegen_working_convert!(convert_double, expected = "double", input = Type::Double);

    test_codegen_working_convert!(convert_int, expected = "int", input = Type::Int32);

    test_codegen_working_convert!(convert_long, expected = "long", input = Type::Int64);

    test_codegen_working_convert!(
        convert_javascript,
        expected = "javascript",
        input = Type::Javascript
    );

    test_codegen_working_convert!(
        convert_javascript_with_scope,
        expected = "javascriptWithScope",
        input = Type::JavascriptWithScope
    );

    test_codegen_working_convert!(convert_max_key, expected = "maxKey", input = Type::MaxKey);

    test_codegen_working_convert!(convert_min_key, expected = "minKey", input = Type::MinKey);

    test_codegen_working_convert!(convert_null, expected = "null", input = Type::Null);

    test_codegen_working_convert!(
        convert_object_id,
        expected = "objectId",
        input = Type::ObjectId
    );

    test_codegen_working_convert!(
        convert_regular_expression,
        expected = "regex",
        input = Type::RegularExpression
    );

    test_codegen_working_convert!(convert_string, expected = "string", input = Type::String);

    test_codegen_working_convert!(convert_symbol, expected = "symbol", input = Type::Symbol);

    test_codegen_working_convert!(
        convert_timestamp,
        expected = "timestamp",
        input = Type::Timestamp
    );

    test_codegen_working_convert!(
        convert_undefined,
        expected = "undefined",
        input = Type::Undefined
    );
}

mod let_expr {
    use crate::air::{Expression::*, Let, LetVariable, MqlOperator, MqlSemanticOperator};
    use bson::bson;

    test_codegen_expression!(
        no_variables,
        expected = Ok(bson!({
            "$let": {
                "vars": {},
                "in": {
                    "$add": ["$x", "$y"]
                }
            }
        })),
        input = Let(Let {
            vars: vec![],
            inside: Box::new(MqlSemanticOperator(MqlSemanticOperator {
                op: MqlOperator::Add,
                args: vec![
                    FieldRef("x".to_string().into()),
                    FieldRef("y".to_string().into()),
                ],
            })),
        })
    );

    test_codegen_expression!(
        one_variable,
        expected = Ok(bson!({
            "$let": {
                "vars": {
                    "v_x": "$x"
                },
                "in": {
                    "$add": ["$$v_x", "$y"]
                }
            }
        })),
        input = Let(Let {
            vars: vec![LetVariable {
                name: "v_x".to_string(),
                expr: Box::new(FieldRef("x".to_string().into())),
            }],
            inside: Box::new(MqlSemanticOperator(MqlSemanticOperator {
                op: MqlOperator::Add,
                args: vec![
                    Variable("v_x".to_string().into()),
                    FieldRef("y".to_string().into()),
                ],
            })),
        })
    );

    test_codegen_expression!(
        multiple_variables,
        expected = Ok(bson!({
            "$let": {
                "vars": {
                    "v_x": "$x",
                    "v_y": "$y",
                    "v_z": "$z"
                },
                "in": {
                    "$add": ["$$v_x", "$$v_y", "$$v_z"]
                }
            }
        })),
        input = Let(Let {
            vars: vec![
                LetVariable {
                    name: "v_x".to_string(),
                    expr: Box::new(FieldRef("x".to_string().into())),
                },
                LetVariable {
                    name: "v_y".to_string(),
                    expr: Box::new(FieldRef("y".to_string().into())),
                },
                LetVariable {
                    name: "v_z".to_string(),
                    expr: Box::new(FieldRef("z".to_string().into())),
                },
            ],
            inside: Box::new(MqlSemanticOperator(MqlSemanticOperator {
                op: MqlOperator::Add,
                args: vec![
                    Variable("v_x".to_string().into()),
                    Variable("v_y".to_string().into()),
                    Variable("v_z".to_string().into()),
                ],
            })),
        })
    );
}

mod regex_match {
    use crate::air::{Expression::*, LiteralValue, RegexMatch};
    use bson::bson;

    test_codegen_expression!(
        regex_match_no_options,
        expected = Ok(
            bson!({ "$regexMatch": {"input": {"$literal": "input"}, "regex": {"$literal": "regex"}}})
        ),
        input = RegexMatch(RegexMatch {
            input: Box::new(Literal(LiteralValue::String("input".to_string()))),
            regex: Box::new(Literal(LiteralValue::String("regex".to_string()))),
            options: None
        })
    );

    test_codegen_expression!(
        regex_match_options,
        expected = Ok(
            bson!({ "$regexMatch": {"input": {"$literal": "input"}, "regex": {"$literal": "regex"}, "options": {"$literal": "options"}}})
        ),
        input = RegexMatch(RegexMatch {
            input: Box::new(Literal(LiteralValue::String("input".to_string()))),
            regex: Box::new(Literal(LiteralValue::String("regex".to_string()))),
            options: Some(Box::new(Literal(LiteralValue::String(
                "options".to_string()
            ))),)
        })
    );
}

mod map {
    use crate::air::{Expression::*, LiteralValue, Map};
    use bson::bson;

    test_codegen_expression!(
        without_as,
        expected =
            Ok(bson!({ "$map": {"input": {"$literal": "input"}, "in": {"$literal": "inside"}}})),
        input = Map(Map {
            input: Box::new(Literal(LiteralValue::String("input".to_string()))),
            as_name: None,
            inside: Box::new(Literal(LiteralValue::String("inside".to_string()))),
        })
    );

    test_codegen_expression!(
        with_as,
        expected = Ok(
            bson!({ "$map": {"input": {"$literal": "input"}, "in": {"$literal": "inside"}, "as": "x"}})
        ),
        input = Map(Map {
            input: Box::new(Literal(LiteralValue::String("input".to_string()))),
            as_name: Some("x".to_string()),
            inside: Box::new(Literal(LiteralValue::String("inside".to_string()))),
        })
    );
}

mod filter {
    use crate::air::{Expression::*, Filter, LiteralValue};
    use bson::bson;

    test_codegen_expression!(
        without_as,
        expected = Ok(
            bson!({ "$filter": {"input": {"$literal": "input"}, "cond": {"$literal": "inside"}}})
        ),
        input = Filter(Filter {
            input: Box::new(Literal(LiteralValue::String("input".to_string()))),
            as_name: None,
            inside: Box::new(Literal(LiteralValue::String("inside".to_string()))),
        })
    );

    test_codegen_expression!(
        with_as,
        expected = Ok(
            bson!({ "$filter": {"input": {"$literal": "input"}, "cond": {"$literal": "inside"}, "as": "x"}})
        ),
        input = Filter(Filter {
            input: Box::new(Literal(LiteralValue::String("input".to_string()))),
            as_name: Some("x".to_string()),
            inside: Box::new(Literal(LiteralValue::String("inside".to_string()))),
        })
    );
}

mod reduce {
    use crate::air::{Expression::*, LiteralValue, Reduce};
    use bson::bson;

    test_codegen_expression!(
        simple,
        expected = Ok(
            bson!({ "$reduce": {"input": {"$literal": "input"}, "initialValue": {"$literal": "init"}, "in": {"$literal": "inside"}}})
        ),
        input = Reduce(Reduce {
            input: Box::new(Literal(LiteralValue::String("input".to_string()))),
            init_value: Box::new(Literal(LiteralValue::String("init".to_string()))),
            inside: Box::new(Literal(LiteralValue::String("inside".to_string()))),
        })
    );
}

mod subquery_exists {
    use crate::{
        air::{
            Collection, Expression::*, LetVariable, Project, ProjectItem, Stage::*, SubqueryExists,
        },
        unchecked_unique_linked_hash_map,
        util::ROOT,
    };
    use bson::bson;

    test_codegen_expression!(
        subquery_exists_uncorrelated,
        expected = Ok(bson!({
            "$subqueryExists": {
                "db": "test",
                "collection": "foo",
                "let": {},
                "pipeline": [
                    {"$project": {"foo": "$$ROOT"}}
                ]
            }
        })),
        input = SubqueryExists(SubqueryExists {
            let_bindings: vec![],
            pipeline: Box::new(Project(Project {
                source: Box::new(Collection(Collection {
                    db: "test".to_string(),
                    collection: "foo".to_string(),
                })),
                specifications: unchecked_unique_linked_hash_map! {
                    "foo".to_string() => ProjectItem::Assignment(ROOT.clone()),
                },
            })),
        })
    );

    test_codegen_expression!(
        subquery_exists_correlated,
        expected = Ok(bson::bson!(
            {"$subqueryExists": {
                "db": "test",
                "collection": "bar",
                "let": {"vfoo_0": "$foo"},
                "pipeline": [
                    {"$project": {"bar": "$$ROOT"}},
                    {"$project": {"__bot": {"a": "$$vfoo_0.a"}}}
                ]
            }}
        )),
        input = SubqueryExists(SubqueryExists {
            let_bindings: vec![LetVariable {
                name: "vfoo_0".to_string(),
                expr: Box::new(FieldRef("foo".to_string().into())),
            },],
            pipeline: Box::new(Project(Project {
                source: Box::new(Project(Project {
                    source: Box::new(Collection(Collection {
                        db: "test".to_string(),
                        collection: "bar".to_string(),
                    })),
                    specifications: unchecked_unique_linked_hash_map! {
                        "bar".to_string() => ProjectItem::Assignment(ROOT.clone()),
                    },
                })),
                specifications: unchecked_unique_linked_hash_map! {
                    "__bot".to_string() => ProjectItem::Assignment(Document(unchecked_unique_linked_hash_map! {
                        "a".to_string() => Variable("vfoo_0.a".to_string().into()),
                    })),
                },
            })),
        })
    );
}

mod subquery {
    use crate::{
        air::{
            Collection, Documents, Expression::*, LetVariable, Project, ProjectItem, Stage::*,
            Subquery,
        },
        unchecked_unique_linked_hash_map,
        util::ROOT,
    };
    use bson::bson;

    test_codegen_expression!(
        no_db_or_coll,
        expected = Ok(bson!({
            "$subquery": {
                "let": {},
                "outputPath": ["arr"],
                "pipeline": [
                    {"$documents": []},
                    {"$project": {"arr": "$$ROOT"}}
                ]
            }
        })),
        input = Subquery(Subquery {
            let_bindings: vec![],
            output_path: vec!["arr".to_string()],
            pipeline: Box::new(Project(Project {
                source: Box::new(Documents(Documents { array: vec![] })),
                specifications: unchecked_unique_linked_hash_map! {
                    "arr".to_string() => ProjectItem::Assignment(ROOT.clone()),
                }
            })),
        })
    );

    test_codegen_expression!(
        fully_specified,
        expected = Ok(bson!({
            "$subquery": {
                "db": "test",
                "collection": "bar",
                "let": {
                    "vfoo_0": "$foo",
                    "vbaz_0": "$baz"
                },
                "outputPath": ["__bot", "a"],
                "pipeline": [
                    {"$project": {"bar": "$$ROOT"}},
                    {"$project": {"__bot": {"a": "$$vfoo_0.a"}}}
                ]
            }
        })),
        input = Subquery(Subquery {
            let_bindings: vec![
                LetVariable {
                    name: "vfoo_0".to_string(),
                    expr: Box::new(FieldRef("foo".to_string().into())),
                },
                LetVariable {
                    name: "vbaz_0".to_string(),
                    expr: Box::new(FieldRef("baz".to_string().into())),
                },
            ],
            output_path: vec!["__bot".to_string(), "a".to_string()],
            pipeline: Box::new(Project(Project {
                source: Box::new(Project(Project {
                    source: Box::new(Collection(Collection {
                        db: "test".to_string(),
                        collection: "bar".to_string(),
                    })),
                    specifications: unchecked_unique_linked_hash_map! {
                        "bar".to_string() => ProjectItem::Assignment(ROOT.clone()),
                    }
                })),
                specifications: unchecked_unique_linked_hash_map! {
                    "__bot".to_string() => ProjectItem::Assignment(Document(unchecked_unique_linked_hash_map! {
                        "a".to_string() => Variable("vfoo_0.a".to_string().into()),
                    })),
                }
            })),
        })
    );
}

mod subquery_comparison {
    use crate::{
        air::{
            Collection, Documents, Expression::*, LetVariable, Project, ProjectItem, Stage::*,
            Subquery, SubqueryComparison, SubqueryComparisonOp, SubqueryComparisonOpType,
            SubqueryModifier,
        },
        unchecked_unique_linked_hash_map,
        util::ROOT,
    };
    use bson::bson;

    test_codegen_expression!(
        no_db_or_coll,
        expected = Ok(bson!({
            "$subqueryComparison": {
                "op": "eq",
                "modifier": "any",
                "arg": "$x",
                "subquery": {
                    "let": {},
                    "outputPath": ["arr"],
                    "pipeline": [
                        {"$documents": []},
                        {"$project": {"arr": "$$ROOT"}}
                    ]
                }
            }
        })),
        input = SubqueryComparison(SubqueryComparison {
            op: SubqueryComparisonOp::Eq,
            op_type: SubqueryComparisonOpType::Mql,
            modifier: SubqueryModifier::Any,
            arg: Box::new(FieldRef("x".to_string().into())),
            subquery: Box::new(Subquery {
                let_bindings: vec![],
                output_path: vec!["arr".to_string()],
                pipeline: Box::new(Project(Project {
                    source: Box::new(Documents(Documents { array: vec![] })),
                    specifications: unchecked_unique_linked_hash_map! {
                        "arr".to_string() => ProjectItem::Assignment(ROOT.clone()),
                    }
                })),
            }),
        })
    );

    test_codegen_expression!(
        sql_op_type,
        expected = Ok(bson!({
            "$subqueryComparison": {
                "op": "sqlEq",
                "modifier": "any",
                "arg": "$x",
                "subquery": {
                    "let": {},
                    "outputPath": ["arr"],
                    "pipeline": [
                        {"$documents": []},
                        {"$project": {"arr": "$$ROOT"}}
                    ]
                }
            }
        })),
        input = SubqueryComparison(SubqueryComparison {
            op: SubqueryComparisonOp::Eq,
            op_type: SubqueryComparisonOpType::Sql,
            modifier: SubqueryModifier::Any,
            arg: Box::new(FieldRef("x".to_string().into())),
            subquery: Box::new(Subquery {
                let_bindings: vec![],
                output_path: vec!["arr".to_string()],
                pipeline: Box::new(Project(Project {
                    source: Box::new(Documents(Documents { array: vec![] })),
                    specifications: unchecked_unique_linked_hash_map! {
                        "arr".to_string() => ProjectItem::Assignment(ROOT.clone()),
                    }
                })),
            }),
        })
    );

    test_codegen_expression!(
        fully_specified,
        expected = Ok(bson!({
            "$subqueryComparison": {
                "op": "gt",
                "modifier": "all",
                "arg": "$x",
                "subquery": {
                    "db": "test",
                    "collection": "bar",
                    "let": {
                        "vfoo_0": "$foo",
                        "vbaz_0": "$baz"
                    },
                    "outputPath": ["__bot", "a"],
                    "pipeline": [
                        {"$project": {"bar": "$$ROOT"}},
                        {"$project": {"__bot": {"a": "$$vfoo_0.a"}}}
                    ]
                }
            }
        })),
        input = SubqueryComparison(SubqueryComparison {
            op: SubqueryComparisonOp::Gt,
            op_type: SubqueryComparisonOpType::Mql,
            modifier: SubqueryModifier::All,
            arg: Box::new(FieldRef("x".to_string().into())),
            subquery: Box::new(Subquery {
                let_bindings: vec![
                    LetVariable {
                        name: "vfoo_0".to_string(),
                        expr: Box::new(FieldRef("foo".to_string().into())),
                    },
                    LetVariable {
                        name: "vbaz_0".to_string(),
                        expr: Box::new(FieldRef("baz".to_string().into())),
                    },
                ],
                output_path: vec!["__bot".to_string(), "a".to_string()],
                pipeline: Box::new(Project(Project {
                    source: Box::new(Project(Project {
                        source: Box::new(Collection(Collection {
                            db: "test".to_string(),
                            collection: "bar".to_string(),
                        })),
                        specifications: unchecked_unique_linked_hash_map! {
                            "bar".to_string() => ProjectItem::Assignment(ROOT.clone()),
                        }
                    })),
                    specifications: unchecked_unique_linked_hash_map! {
                        "__bot".to_string() => ProjectItem::Assignment(Document(unchecked_unique_linked_hash_map! {
                            "a".to_string() => Variable("vfoo_0.a".to_string().into()),
                        })),
                    }
                })),
            }),
        })
    );
}
