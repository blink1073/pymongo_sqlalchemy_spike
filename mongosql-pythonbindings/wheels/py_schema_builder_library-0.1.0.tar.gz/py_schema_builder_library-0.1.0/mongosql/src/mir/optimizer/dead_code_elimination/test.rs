use crate::{
    SchemaCheckingMode,
    catalog::Catalog,
    map, mir,
    mir::{
        optimizer::{Optimizer, dead_code_elimination::DeadCodeEliminator},
        schema::{SchemaCache, SchemaInferenceState},
        *,
    },
    schema::{Atomic, Document, Satisfaction, Schema, SchemaEnvironment},
    set, unchecked_unique_linked_hash_map,
    util::{mir_collection, mir_field_access},
};
use agg_ast::definitions::Namespace;
use lazy_static::lazy_static;

lazy_static! {
    static ref CATALOG: Catalog = Catalog::new(map! {
        Namespace {database: "db".into(), collection: "bar".into()} => Schema::Document(Document {
            keys: map! {
                "a".to_string() => Schema::Atomic(Atomic::Integer),
                "b".to_string() => Schema::Atomic(Atomic::Integer),
                "c".to_string() => Schema::Atomic(Atomic::Double),
            },
            required: set! {},
            additional_properties: true,
            ..Default::default()
            }),
    });
}

macro_rules! test_dead_code_elimination {
    ($func_name:ident, expected = $expected:expr, expected_changed = $expected_changed:expr, input = $input:expr) => {
        #[test]
        fn $func_name() {
            let input = $input;
            let expected = $expected;

            let state = SchemaInferenceState::new(
                0u16,
                SchemaEnvironment::default(),
                &*CATALOG,
                map! {},
                SchemaCheckingMode::Relaxed,
            );

            let optimizer = &DeadCodeEliminator;
            let (actual, actual_changed) =
                optimizer.optimize(input, SchemaCheckingMode::Relaxed, &state);
            assert_eq!($expected_changed, actual_changed);
            assert_eq!(expected, actual);
        }
    };
}
macro_rules! test_dead_code_elimination_no_op {
    ($func_name:ident, $input:expr) => {
        test_dead_code_elimination! { $func_name, expected = $input, expected_changed = false, input = $input }
    };
}

test_dead_code_elimination_no_op!(
    cannot_eliminate_non_project_source_for_group,
    Stage::Group(Group {
        source: Box::new(Stage::Filter(Filter {
            source: mir_collection("db", "bar"),
            condition: Expression::Literal(LiteralValue::Boolean(true),),
            cache: SchemaCache::new(),
        })),
        keys: vec![],
        aggregations: vec![],
        scope: 0u16,
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination!(
    swap_group_and_project,
    expected = Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Project(Project {
            is_add_fields: false,
            source: Box::new(Stage::Group(Group {
                source: mir_collection("db", "bar"),
                keys: vec![
                    OptionallyAliasedExpr::Aliased(AliasedExpr {
                        alias: "a".to_string(),
                        expr: Expression::FieldAccess(FieldAccess::new(
                            Box::new(Expression::Reference(("bar", 0u16).into())),
                            "a".to_string(),
                        )),
                    }),
                    OptionallyAliasedExpr::Unaliased(Expression::FieldAccess(FieldAccess::new(
                        Box::new(Expression::Reference(("bar", 0u16).into())),
                        "b".to_string(),
                    ))),
                ],
                aggregations: vec![AliasedAggregation {
                    alias: "agg".to_string(),
                    agg_expr: AggregationExpr::Function(AggregationFunctionApplication {
                        function: AggregationFunction::Avg,
                        distinct: false,
                        arg: Box::new(Expression::FieldAccess(FieldAccess::new(
                            Box::new(Expression::Reference(("bar", 0u16).into())),
                            "c".to_string(),
                        ))),
                        arg_is_possibly_doc: Satisfaction::Not,
                    }),
                }],
                scope: 0u16,
                cache: SchemaCache::new(),
            })),
            expression: map! {
                ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
                mir::binding_tuple::Key::bot(0) => mir::Expression::Reference(mir::binding_tuple::Key::bot(0).into()),
            },
            cache: SchemaCache::new(),
        })),
        expression: map! {
            ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    }),
    expected_changed = true,
    input = Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Group(Group {
            source: Box::new(Stage::Project(Project {
                is_add_fields: false,
                source: mir_collection("db", "bar"),
                expression: map! {
                    ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
                },
                cache: SchemaCache::new(),
            })),
            keys: vec![
                OptionallyAliasedExpr::Aliased(AliasedExpr {
                    alias: "a".to_string(),
                    expr: Expression::FieldAccess(FieldAccess::new(
                        Box::new(Expression::Reference(("foo", 0u16).into())),
                        "a".to_string(),
                    ))
                }),
                OptionallyAliasedExpr::Unaliased(Expression::FieldAccess(FieldAccess::new(
                    Box::new(Expression::Reference(("foo", 0u16).into())),
                    "b".to_string(),
                ))),
            ],
            aggregations: vec![AliasedAggregation {
                alias: "agg".to_string(),
                agg_expr: AggregationExpr::Function(AggregationFunctionApplication {
                    function: AggregationFunction::Avg,
                    distinct: false,
                    arg: Box::new(Expression::FieldAccess(FieldAccess::new(
                        Box::new(Expression::Reference(("foo", 0u16).into())),
                        "c".to_string(),
                    ))),
                    arg_is_possibly_doc: Satisfaction::Not,
                }),
            }],
            scope: 0u16,
            cache: SchemaCache::new(),
        })),
        expression: map! {
            ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination!(
    swap_group_and_project_outer_project_agg_only,
    expected = Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Project(Project {
            is_add_fields: false,
            source: Box::new(Stage::Group(Group {
                source: mir_collection("db", "bar"),
                keys: vec![
                    OptionallyAliasedExpr::Aliased(AliasedExpr {
                        alias: "a".to_string(),
                        expr: Expression::FieldAccess(FieldAccess::new(
                            Box::new(Expression::Reference(("bar", 0u16).into())),
                            "a".to_string(),
                        ))
                    }),
                    OptionallyAliasedExpr::Unaliased(Expression::FieldAccess(FieldAccess::new(
                        Box::new(Expression::Reference(("bar", 0u16).into())),
                        "b".to_string(),
                    ))),
                ],
                aggregations: vec![AliasedAggregation {
                    alias: "agg".to_string(),
                    agg_expr: AggregationExpr::Function(AggregationFunctionApplication {
                        function: AggregationFunction::Avg,
                        distinct: false,
                        arg: Box::new(Expression::FieldAccess(FieldAccess::new(
                            Box::new(Expression::Reference(("bar", 0u16).into())),
                            "c".to_string(),
                        ))),
                        arg_is_possibly_doc: Satisfaction::Not,
                    }),
                }],
                scope: 0u16,
                cache: SchemaCache::new(),
            })),
            expression: map! {
                mir::binding_tuple::Key::bot(0) => mir::Expression::Reference(mir::binding_tuple::Key::bot(0).into()),
                ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
            },
            cache: SchemaCache::new(),
        })),
        expression: map! {
            mir::binding_tuple::Key::bot(0) => mir::Expression::Document(mir::DocumentExpr {
                document: unchecked_unique_linked_hash_map!(
                    "agg".to_string() => mir::Expression::FieldAccess(mir::FieldAccess {
                        expr: Box::new(mir::Expression::Reference(mir::ReferenceExpr{
                            key: mir::binding_tuple::Key::bot(0),
                        })),
                        field: "_agg1".to_string(),
                        is_nullable: false,
                    })
                ),
            })
        },
        cache: SchemaCache::new(),
    }),
    expected_changed = true,
    input = Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Group(Group {
            source: Box::new(Stage::Project(Project {
                is_add_fields: false,
                source: mir_collection("db", "bar"),
                expression: map! {
                    ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
                },
                cache: SchemaCache::new(),
            })),
            keys: vec![
                OptionallyAliasedExpr::Aliased(AliasedExpr {
                    alias: "a".to_string(),
                    expr: Expression::FieldAccess(FieldAccess::new(
                        Box::new(Expression::Reference(("foo", 0u16).into())),
                        "a".to_string(),
                    ))
                }),
                OptionallyAliasedExpr::Unaliased(Expression::FieldAccess(FieldAccess::new(
                    Box::new(Expression::Reference(("foo", 0u16).into())),
                    "b".to_string(),
                ))),
            ],
            aggregations: vec![AliasedAggregation {
                alias: "agg".to_string(),
                agg_expr: AggregationExpr::Function(AggregationFunctionApplication {
                    function: AggregationFunction::Avg,
                    distinct: false,
                    arg: Box::new(Expression::FieldAccess(FieldAccess::new(
                        Box::new(Expression::Reference(("foo", 0u16).into())),
                        "c".to_string(),
                    ))),
                    arg_is_possibly_doc: Satisfaction::Not,
                }),
            }],
            scope: 0u16,
            cache: SchemaCache::new(),
        })),
        expression: map! {
            mir::binding_tuple::Key::bot(0) => mir::Expression::Document(mir::DocumentExpr {
                document: unchecked_unique_linked_hash_map!(
                    "agg".to_string() => mir::Expression::FieldAccess(mir::FieldAccess {
                        expr: Box::new(mir::Expression::Reference(mir::ReferenceExpr{
                            key: mir::binding_tuple::Key::bot(0),
                        })),
                        field: "_agg1".to_string(),
                        is_nullable: false,
                    })
                ),
            })
        },
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination_no_op!(
    cannot_eliminate_project_source_for_group_if_not_all_sources_are_substitutable,
    Stage::Group(Group {
        source: Box::new(Stage::Project(Project {
            is_add_fields: false,
            source: mir_collection("db", "bar"),
            expression: map! {
                ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
            },
            cache: SchemaCache::new(),
        })),
        keys: vec![
            OptionallyAliasedExpr::Aliased(AliasedExpr {
                alias: "a".to_string(),
                expr: Expression::FieldAccess(FieldAccess::new(
                    Box::new(Expression::Reference(("foo", 0u16).into())),
                    "a".to_string(),
                ))
            }),
            OptionallyAliasedExpr::Unaliased(Expression::FieldAccess(FieldAccess::new(
                Box::new(Expression::Reference(("bad", 0u16).into())),
                "b".to_string(),
            ))),
        ],
        aggregations: vec![AliasedAggregation {
            alias: "agg".to_string(),
            agg_expr: AggregationExpr::Function(AggregationFunctionApplication {
                function: AggregationFunction::Avg,
                distinct: false,
                arg: Box::new(Expression::FieldAccess(FieldAccess::new(
                    Box::new(Expression::Reference(("bad", 0u16).into())),
                    "c".to_string(),
                ))),
                arg_is_possibly_doc: Satisfaction::Not,
            }),
        }],
        scope: 0u16,
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination_no_op!(
    cannot_eliminate_non_project_source_for_project,
    Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Filter(Filter {
            source: mir_collection("db", "bar"),
            condition: Expression::Literal(LiteralValue::Boolean(true),),
            cache: SchemaCache::new(),
        })),
        expression: map! {
            ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination_no_op!(
    cannot_eliminate_non_add_fields_source_for_project,
    Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Project(Project {
            is_add_fields: false,
            source: mir_collection("db", "bar"),
            expression: map! {
                ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
            },
            cache: SchemaCache::new(),
        })),
        expression: map! {
            ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination_no_op!(
    cannot_eliminate_any_source_for_add_fields,
    Stage::Project(Project {
        is_add_fields: true,
        source: Box::new(Stage::Project(Project {
            is_add_fields: true,
            source: mir_collection("db", "bar"),
            expression: map! {
                ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
            },
            cache: SchemaCache::new(),
        })),
        expression: map! {
            ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination_no_op!(
    cannot_eliminate_if_project_and_add_fields_define_different_fields,
    Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Project(Project {
            is_add_fields: true,
            source: mir_collection("db", "bar"),
            expression: map! {
                ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
            },
            cache: SchemaCache::new(),
        })),
        expression: map! {
            ("foo2", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination!(
    swapping_group_stage_with_project_that_outputs_a_literal_document_replaces_doc_with_ref,
    expected = Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Group(Group {
            source: mir_collection("db", "bar"),
            keys: vec![OptionallyAliasedExpr::Unaliased(Expression::FieldAccess(
                FieldAccess::new(
                    Box::new(Expression::Document(mir::DocumentExpr {
                        document: unchecked_unique_linked_hash_map!(
                            "a".to_string() => *mir_field_access("bar", "a", true),
                            "b".to_string() => *mir_field_access("bar", "b", true),
                            "c".to_string() => *mir_field_access("bar", "c", true),
                        ),
                    })),
                    "b".to_string(),
                )
            ))],
            aggregations: vec![],
            scope: 0u16,
            cache: SchemaCache::new(),
        })),
        expression: map! {
            ("bar", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    }),
    expected_changed = true,
    input = Stage::Group(Group {
        source: Box::new(Stage::Project(Project {
            is_add_fields: false,
            source: mir_collection("db", "bar"),
            expression: map! {
                ("bar", 0u16).into() => mir::Expression::Document(mir::DocumentExpr {
                    document: unchecked_unique_linked_hash_map!(
                        "a".to_string() => *mir_field_access("bar", "a", true),
                        "b".to_string() => *mir_field_access("bar", "b", true),
                        "c".to_string() => *mir_field_access("bar", "c", true),
                    ),
                })
            },
            cache: SchemaCache::new(),
        })),
        keys: vec![OptionallyAliasedExpr::Unaliased(Expression::FieldAccess(
            FieldAccess::new(
                Box::new(Expression::Reference(("bar", 0u16).into())),
                "b".to_string(),
            )
        ))],
        aggregations: vec![],
        scope: 0u16,
        cache: SchemaCache::new(),
    })
);

test_dead_code_elimination!(
    remove_add_fields_before_project_that_defines_same_fields,
    expected = Stage::Project(Project {
        is_add_fields: false,
        source: mir_collection("db", "bar"),
        expression: map! {
            ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    }),
    expected_changed = true,
    input = Stage::Project(Project {
        is_add_fields: false,
        source: Box::new(Stage::Project(Project {
            is_add_fields: true,
            source: mir_collection("db", "bar"),
            expression: map! {
                ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
            },
            cache: SchemaCache::new(),
        })),
        expression: map! {
            ("foo", 0u16).into() => mir::Expression::Reference(("bar", 0u16).into()),
        },
        cache: SchemaCache::new(),
    })
);
