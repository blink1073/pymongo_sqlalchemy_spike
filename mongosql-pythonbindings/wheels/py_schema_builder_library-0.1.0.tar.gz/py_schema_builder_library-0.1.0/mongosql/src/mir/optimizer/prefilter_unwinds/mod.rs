///
/// Prefilter Unwinds
///
/// The Prefilter Unwinds pass generates ElemMatch matches before Unwind stages
/// when there is a Filter after the Unwind that cannot move passed the Unwind
/// since it uses an Opaque field from the Unwind. The ElemMatch will potentially
/// not be entirely selective, but in conjunction with Stage Movement, it can possibly
/// allow the usage of more indexes that can massively improve query performance.
///
/// As an example of where this can really help, consider:
/// SELECT * FROM UNWIND(foo WITH path => v) WHERE v = 6
///
/// The ElemMatch on v = 6 will result in an index that removes any documents where the v array
/// does not contain 6. Note that the original Filter will be maintained after the Unwind so that
/// any value that is not explicitly 6 will be removed still.
///
/// In general, this can reduce a very large COL_SCANs into a possibly very selective IDX_SCANs
/// depending on the size of the arrays and volatility of data in the arrays.
///
#[cfg(test)]
mod test;

use super::Optimizer;
use crate::{
    SchemaCheckingMode,
    mir::{
        ElemMatch, Expression, FieldPath, Filter, LiteralValue, MatchFilter,
        MatchLanguageComparison, MatchLanguageComparisonOp, MatchLanguageLogical,
        MatchLanguageLogicalOp, MatchQuery, MqlStage, ScalarFunction, ScalarFunctionApplication,
        Stage, Unwind,
        schema::{SchemaCache, SchemaInferenceState},
        visitor::Visitor,
    },
};

pub(crate) struct PrefilterUnwindsOptimizer {}

impl Optimizer for PrefilterUnwindsOptimizer {
    fn optimize(
        &self,
        st: Stage,
        _sm: SchemaCheckingMode,
        _schema_state: &SchemaInferenceState,
    ) -> (Stage, bool) {
        PrefilterUnwindsOptimizer::prefilter_unwinds(st)
    }
}

impl PrefilterUnwindsOptimizer {
    fn prefilter_unwinds(st: Stage) -> (Stage, bool) {
        let mut visitor = PrefilterUnwindsVisitor::default();
        let new_stage = visitor.visit_stage(st);
        (new_stage, visitor.changed)
    }
}

#[derive(Default)]
struct PrefilterUnwindsVisitor {
    changed: bool,
}

impl Visitor for PrefilterUnwindsVisitor {
    fn visit_stage(&mut self, node: Stage) -> Stage {
        let node = node.walk(self);
        match node {
            Stage::MqlIntrinsic(MqlStage::MatchFilter(f)) => {
                // Unbox once so source/condition/cache can be moved out independently.
                let MatchFilter {
                    source,
                    condition,
                    cache,
                } = *f;
                match *source {
                    // If the Unwind has already been pre-filtered, ignore it.
                    Stage::Unwind(u) if !u.is_prefiltered => {
                        let field_uses = condition.field_uses();

                        // Rebuild the MatchFilter over `source`, preserving cache.
                        let rebuild = |source: Box<Stage>, condition: MatchQuery| {
                            Stage::MqlIntrinsic(MqlStage::MatchFilter(Box::new(MatchFilter {
                                source,
                                condition,
                                cache: cache.clone(),
                            })))
                        };

                        let Some(field_uses) = field_uses else {
                            return rebuild(Box::new(Stage::Unwind(u)), condition);
                        };
                        if field_uses.len() != 1 {
                            return rebuild(Box::new(Stage::Unwind(u)), condition);
                        }

                        let field_use = field_uses.into_iter().next().unwrap();
                        let opaque_field_defines = u.opaque_field_defines();
                        if !opaque_field_defines.contains(&field_use)
                            || field_use.fields.first() == u.index.as_ref()
                        {
                            return rebuild(Box::new(Stage::Unwind(u)), condition);
                        }

                        let (new_source, changed) =
                            generate_match_prefilter(field_use, u.source, &condition);
                        self.changed |= changed;
                        rebuild(
                            Box::new(Stage::Unwind(Unwind {
                                source: new_source,
                                // Ensure that future runs of this optimizer
                                // do not pre-filter this Unwind again.
                                is_prefiltered: changed,
                                ..u
                            })),
                            condition,
                        )
                    }
                    other => Stage::MqlIntrinsic(MqlStage::MatchFilter(Box::new(MatchFilter {
                        source: Box::new(other),
                        condition,
                        cache,
                    }))),
                }
            }
            Stage::Filter(f) => match *f.source {
                // If the Unwind has already been pre-filtered, ignore it.
                Stage::Unwind(u) if !u.is_prefiltered => {
                    let field_uses = f.condition.field_uses();
                    let field_uses = if let Some(field_uses) = field_uses {
                        field_uses
                    } else {
                        return Stage::Filter(Filter {
                            source: Box::new(Stage::Unwind(u)),
                            condition: f.condition,
                            ..f
                        });
                    };
                    if field_uses.len() == 1 {
                        let field_use = field_uses.into_iter().next().unwrap();
                        let opaque_field_defines = u.opaque_field_defines();
                        if !opaque_field_defines.contains(&field_use) {
                            return Stage::Filter(Filter {
                                source: Box::new(Stage::Unwind(u)),
                                condition: f.condition,
                                ..f
                            });
                        }
                        if field_use.fields.first() == u.index.as_ref() {
                            return Stage::Filter(Filter {
                                source: Box::new(Stage::Unwind(u)),
                                condition: f.condition,
                                ..f
                            });
                        }
                        let (new_source, changed) =
                            generate_prefilter(field_use, u.source, &f.condition);
                        self.changed |= changed;
                        Stage::Filter(Filter {
                            source: Box::new(Stage::Unwind(Unwind {
                                source: new_source,
                                // Ensure that future runs of this optimizer
                                // do not pre-filter this Unwind again.
                                is_prefiltered: changed,
                                ..u
                            })),
                            condition: f.condition,
                            cache: f.cache,
                        })
                    } else {
                        Stage::Filter(Filter {
                            source: Box::new(Stage::Unwind(u)),
                            condition: f.condition,
                            cache: f.cache,
                        })
                    }
                }
                _ => Stage::Filter(Filter { ..f }),
            },
            _ => node,
        }
    }
}

// generate_match_prefilter returns the original source unchanged if it cannot
// extract a useful comparison from the already-lowered match condition. Unlike
// generate_prefilter (which reads an Expression), this handles the MatchQuery
// conditions produced once rewrite_to_match_language has run.
fn generate_match_prefilter(
    field: FieldPath,
    source: Box<Stage>,
    condition: &MatchQuery,
) -> (Box<Stage>, bool) {
    let Some((function, lit)) = extract_comparison(condition) else {
        return (source, false);
    };
    (
        Stage::MqlIntrinsic(MqlStage::MatchFilter(Box::new(MatchFilter {
            source,
            condition: generate_comparison_elem_match_query(function, field, lit),
            cache: SchemaCache::new(),
        })))
        .into(),
        true,
    )
}

// Pulls (op, literal) out of a lowered match condition.
// For the AND operator, grabs the first comparison that has a non-null literal.
// The rewrite_to_match_langauge pass will prevent any null literal comparisons from being used in match language.
fn extract_comparison(condition: &MatchQuery) -> Option<(MatchLanguageComparisonOp, LiteralValue)> {
    match condition {
        MatchQuery::Comparison(c) => Some((c.function, c.arg.clone())),
        MatchQuery::Logical(MatchLanguageLogical {
            op: MatchLanguageLogicalOp::And,
            args,
            ..
        }) => args.iter().find_map(|arg| match arg {
            MatchQuery::Comparison(c) if c.arg != LiteralValue::Null => {
                Some((c.function, c.arg.clone()))
            }
            _ => None,
        }),
        _ => None,
    }
}

// generate_prefilter returns the original source Stage, if it fails to generate a useful ElemMatchLanguage
fn generate_prefilter(
    field: FieldPath,
    source: Box<Stage>,
    condition: &Expression,
) -> (Box<Stage>, bool) {
    if let Expression::ScalarFunction(ScalarFunctionApplication {
        function: f,
        args: a,
        ..
    }) = condition
    {
        if matches!(f, ScalarFunction::Between) {
            let (lower_bound, upper_bound) =
                if let Some((lower_bound, upper_bound)) = get_between_literals(a) {
                    (lower_bound, upper_bound)
                } else {
                    return (source, false);
                };
            return (
                Stage::MqlIntrinsic(MqlStage::MatchFilter(Box::new(MatchFilter {
                    source,
                    condition: generate_between_elem_match_query(field, lower_bound, upper_bound),
                    cache: SchemaCache::new(),
                })))
                .into(),
                true,
            );
        }
        let lit = if let Some(lit) = get_comparison_literal(a) {
            lit
        } else {
            return (source, false);
        };
        let function: MatchLanguageComparisonOp = if let Ok(op) = (*f).try_into() {
            op
        } else {
            return (source, false);
        };
        return (
            Stage::MqlIntrinsic(MqlStage::MatchFilter(Box::new(MatchFilter {
                source,
                condition: generate_comparison_elem_match_query(function, field, lit),
                cache: SchemaCache::new(),
            })))
            .into(),
            true,
        );
    }
    (source, false)
}

fn generate_comparison_elem_match_query(
    function: MatchLanguageComparisonOp,
    field: FieldPath,
    lit: LiteralValue,
) -> MatchQuery {
    MatchQuery::ElemMatch(ElemMatch {
        input: field,
        condition: generate_match_comparison(function, lit).into(),
        cache: SchemaCache::new(),
    })
}

fn generate_between_elem_match_query(
    field: FieldPath,
    lower_bound: LiteralValue,
    upper_bound: LiteralValue,
) -> MatchQuery {
    MatchQuery::ElemMatch(ElemMatch {
        input: field,
        condition: MatchQuery::Logical(MatchLanguageLogical {
            op: MatchLanguageLogicalOp::And,
            args: vec![
                generate_match_comparison(MatchLanguageComparisonOp::Gte, lower_bound),
                generate_match_comparison(MatchLanguageComparisonOp::Lte, upper_bound),
            ],
            cache: SchemaCache::new(),
        })
        .into(),
        cache: SchemaCache::new(),
    })
}

fn generate_match_comparison(function: MatchLanguageComparisonOp, lit: LiteralValue) -> MatchQuery {
    MatchQuery::Comparison(MatchLanguageComparison {
        function,
        input: None,
        arg: lit,
        cache: SchemaCache::new(),
    })
}

fn get_comparison_literal(args: &Vec<Expression>) -> Option<LiteralValue> {
    if args.len() != 2 {
        return None;
    }
    match args.as_slice() {
        [Expression::Literal(lit), Expression::FieldAccess(_)] => Some(lit.clone()),
        [Expression::FieldAccess(_), Expression::Literal(lit)] => Some(lit.clone()),
        _ => None,
    }
}

fn get_between_literals(args: &Vec<Expression>) -> Option<(LiteralValue, LiteralValue)> {
    if args.len() != 3 {
        return None;
    }
    match args.as_slice() {
        [
            Expression::FieldAccess(_),
            Expression::Literal(lit1),
            Expression::Literal(lit2),
        ] => Some((lit1.clone(), lit2.clone())),
        _ => None,
    }
}

impl TryFrom<ScalarFunction> for MatchLanguageComparisonOp {
    // We'll never use this error, at this time, so we just make it ()
    type Error = ();

    fn try_from(s: ScalarFunction) -> Result<Self, Self::Error> {
        Ok(match s {
            ScalarFunction::Lt => Self::Lt,
            ScalarFunction::Lte => Self::Lte,
            ScalarFunction::Neq => Self::Ne,
            ScalarFunction::Eq => Self::Eq,
            ScalarFunction::Gt => Self::Gt,
            ScalarFunction::Gte => Self::Gte,
            _ => return Err(()),
        })
    }
}
