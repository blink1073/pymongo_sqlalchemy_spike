use crate::{
    mir::binding_tuple,
    schema::{Satisfaction, Schema},
    usererror::{
        UserError, UserErrorDisplay,
        util::{generate_suggestion, unsat_check},
    },
};

#[derive(Debug, UserErrorDisplay, PartialEq, Eq, Clone)]
pub enum Error {
    // DatasourceNotFoundInSchemaEnv is believed to be an internal error that can't be triggered by users.
    // Error 3007: NoSuchDatasource should cover it. However, since other parts of the code rely
    // on this error to function properly (see ticket SQL-1784 for more details), we've decided not to remove it.
    // Note: The errors.md file does not mention this error because there is no known way to trigger it with a Sql query.
    // Once/if we discover a way to trigger it, we will update the errors.md file accordingly.
    DatasourceNotFoundInSchemaEnv(binding_tuple::Key),
    IncorrectArgumentCount {
        name: &'static str,
        required: IncorrectArgCountPrecision,
        found: usize,
    },
    SchemaChecking {
        name: &'static str,
        required: Box<Schema>,
        found: Box<Schema>,
        var_cause: Option<String>,
    },
    InvalidBinaryDataType,
    AggregationArgumentMustBeSelfComparable(String, Box<Schema>),
    InvalidComparison {
        name: &'static str,
        left: Box<Schema>,
        right: Box<Schema>,
        var_cause: Option<String>,
    },
    CannotMergeObjects(Box<Schema>, Box<Schema>, Satisfaction),
    AccessMissingField(String, Option<Vec<String>>),
    InvalidSubqueryCardinality,
    SortKeyNotSelfComparable(usize, Box<Schema>),
    GroupKeyNotSelfComparable(usize, Box<Schema>),
    UnwindIndexNameConflict(String),
    CollectionNotFound(String, String),
    // HigherOrderFunctionWrapper is used to wrap errors that occur in the context of a higher order
    // function's function argument. For example, MAP(["a", "b"], this + 1) is invalid because the
    // function argument is invalid (`this` has string schema, but `+` expects a numeric schema).
    // This wrapper includes extra context indicating the surrounding higher order function and the
    // root cause of the problem in the function argument. In this example, the root cause is the
    // use of the `this` variable.
    HigherOrderFunctionWrapper {
        name: &'static str,
        cause: HigherOrderFunctionErrorCause,
        error: Box<Error>,
    },
    NoSuchVariable(String),
}

#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum HigherOrderFunctionErrorCause {
    // The initial value provided to the higher order function is semantically invalid.
    InitialValue,

    // The schema of the accumulated value causes uses of the `value` variable to be invalid.
    AccumulatedValueUsage,

    // The schema of the initial value causes uses of the `value` variable to be invalid.
    InitialValueUsage,

    // The schema of the array items causes uses of the `this` variable to be invalid.
    ThisUsage,

    // The function argument for a higher order function is semantically invalid for a reason other
    // than variable usage.
    FunctionArgument,
}

#[derive(Debug, PartialEq, Eq, Clone)]
pub enum IncorrectArgCountPrecision {
    Exact(usize),
    Minimum(usize),
}

impl std::fmt::Display for IncorrectArgCountPrecision {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IncorrectArgCountPrecision::Exact(n) => write!(f, "exactly {n}"),
            IncorrectArgCountPrecision::Minimum(n) => write!(f, "at least {n}"),
        }
    }
}

impl UserError for Error {
    fn code(&self) -> u32 {
        match self {
            Error::DatasourceNotFoundInSchemaEnv(_) => 1000,
            Error::IncorrectArgumentCount { .. } => 1001,
            Error::SchemaChecking { .. } => 1002,
            Error::AggregationArgumentMustBeSelfComparable(_, _) => 1003,
            Error::InvalidComparison { .. } => 1005,
            Error::CannotMergeObjects(_, _, _) => 1006,
            Error::AccessMissingField(_, _) => 1007,
            Error::InvalidSubqueryCardinality => 1008,
            Error::SortKeyNotSelfComparable(_, _) => 1010,
            Error::GroupKeyNotSelfComparable(_, _) => 1011,
            Error::UnwindIndexNameConflict(_) => 1014,
            Error::CollectionNotFound(_, _) => 1016,
            Error::InvalidBinaryDataType => 1019,
            Error::HigherOrderFunctionWrapper { .. } => 1020,
            Error::NoSuchVariable { .. } => 1021,
        }
    }

    fn user_message(&self) -> Option<String> {
        match self {
            Error::DatasourceNotFoundInSchemaEnv(_) => None,
            Error::IncorrectArgumentCount { .. } => None,
            Error::SchemaChecking {
                name,
                required,
                found,
                ..
            } => {
                let simplified_required = Schema::simplify(required);
                let simplified_found = Schema::simplify(found);

                if let Some(message) =
                    unsat_check(vec![simplified_required.clone(), simplified_found.clone()])
                {
                    Some(message)
                } else {
                    let error_msg = format!(
                        "Incorrect argument type for `{name}`. Required: {simplified_required}. Found: {simplified_found}."
                    );
                    let error_msg = Self::error_message_with_any_schema_addendum(
                        error_msg,
                        vec![simplified_found],
                    );
                    Some(error_msg)
                }
            }
            Error::AggregationArgumentMustBeSelfComparable(agg, schema) => {
                let simplified_schema = Schema::simplify(schema);

                if let Some(message) = unsat_check(vec![simplified_schema.clone()]) {
                    Some(message)
                } else {
                    let error_msg = format!(
                        "Cannot perform `{agg}` aggregation over the type `{simplified_schema}` as it is not comparable to itself."
                    );
                    let error_msg = Self::error_message_with_any_schema_addendum(
                        error_msg,
                        vec![simplified_schema],
                    );
                    Some(error_msg)
                }
            }
            Error::InvalidComparison {
                name, left, right, ..
            } => {
                let simplified_s1 = Schema::simplify(left);
                let simplified_s2 = Schema::simplify(right);

                if let Some(message) =
                    unsat_check(vec![simplified_s1.clone(), simplified_s2.clone()])
                {
                    Some(message)
                } else {
                    let error_msg = format!(
                        "Invalid use of `{name}` due to incomparable types: `{simplified_s1}` cannot be compared to `{simplified_s2}`."
                    );
                    let error_msg = Self::error_message_with_any_schema_addendum(
                        error_msg,
                        vec![simplified_s1, simplified_s2],
                    );
                    Some(error_msg)
                }
            }
            Error::AccessMissingField(field, found_fields) => {
                if let Some(possible_fields) = found_fields {
                    let suggestions = generate_suggestion(field, possible_fields);
                    match suggestions {
                        Ok(suggested_fields) => {
                            if suggested_fields.is_empty() {
                                Some(format!(
                                    "Cannot access field `{field}` because it could not be found."
                                ))
                            } else {
                                Some(format!(
                                    "Cannot access field `{field}` because it could not be found. Did you mean: {}",
                                    suggested_fields
                                        .iter()
                                        .map(|x| x.to_string())
                                        .collect::<Vec<String>>()
                                        .join(", ")
                                ))
                            }
                        }
                        Err(e) => Some(format!(
                            "Cannot access field `{field}` because it could not be found. Internal error: {e}"
                        )),
                    }
                } else {
                    Some(format!(
                        "Cannot access field `{field}` because it could not be found."
                    ))
                }
            }
            Error::CannotMergeObjects(s1, s2, _) => {
                let overlap = s1
                    .keys()
                    .into_iter()
                    .filter(|k| !matches!(s2.contains_field(k), Satisfaction::Not))
                    .collect::<Vec<_>>();

                Some(format!(
                    "Cannot merge objects because they have overlapping key(s): `{}`",
                    overlap.join("`, `")
                ))
            }
            Error::InvalidSubqueryCardinality => None,
            Error::SortKeyNotSelfComparable(_, schema) => {
                let simplified_schema = Schema::simplify(schema);

                if let Some(message) = unsat_check(vec![simplified_schema.clone()]) {
                    Some(message)
                } else {
                    let error_msg = format!(
                        "Cannot sort by key because `{simplified_schema}` can't be compared against itself."
                    );
                    let error_msg = Self::error_message_with_any_schema_addendum(
                        error_msg,
                        vec![simplified_schema],
                    );
                    Some(error_msg)
                }
            }
            Error::GroupKeyNotSelfComparable(_, schema) => {
                let simplified_schema = Schema::simplify(schema);

                if let Some(message) = unsat_check(vec![simplified_schema.clone()]) {
                    Some(message)
                } else {
                    let error_msg = format!(
                        "Cannot group by key because `{simplified_schema}` can't be compared against itself.",
                    );
                    let error_msg = Self::error_message_with_any_schema_addendum(
                        error_msg,
                        vec![simplified_schema],
                    );
                    Some(error_msg)
                }
            }
            Error::UnwindIndexNameConflict(_) => None,
            Error::CollectionNotFound(_, _) => None,
            Error::InvalidBinaryDataType => None,
            Error::HigherOrderFunctionWrapper { name, cause, error } => {
                let (cause_desc, cause_message) = match cause {
                    HigherOrderFunctionErrorCause::InitialValue => (
                        "initial value",
                        "The initial value must be semantically valid but was not.",
                    ),
                    HigherOrderFunctionErrorCause::AccumulatedValueUsage => (
                        "function argument",
                        "Invalid usage of variable `value` because of the result of the accumulator function. Recall that usages of the `value` variable must be satisfied by the both the schema of the initial value and the schema of the result of the accumulator function.",
                    ),
                    HigherOrderFunctionErrorCause::InitialValueUsage => (
                        "function argument",
                        "Invalid usage of variable `value` because of the initial value. Recall that usages of the `value` variable must be satisfied by the both the schema of the initial value and the schema of the result of the accumulator function.",
                    ),
                    HigherOrderFunctionErrorCause::ThisUsage => (
                        "function argument",
                        "Invalid usage of variable `this`. Recall that usages of the `this` variable must be satisfied by the schema of the elements of the array.",
                    ),
                    HigherOrderFunctionErrorCause::FunctionArgument => (
                        "function argument",
                        "Ensure the function argument is semantically valid. It must have the correct number of arguments and the arguments must have the correct type.",
                    ),
                };
                let sub_error_message = error
                    .user_message()
                    .unwrap_or_else(|| error.technical_message());
                Some(format!(
                    "Invalid {cause_desc} for `{name}`: {cause_message} Sub-Error Code {}: {}",
                    error.code(),
                    sub_error_message
                ))
            }
            Error::NoSuchVariable(name) => Some(format!("Variable `{name}` does not exist.")),
        }
    }

    fn technical_message(&self) -> String {
        match self {
            Error::DatasourceNotFoundInSchemaEnv(datasource) => {
                format!("datasource {datasource:?} not found in schema environment")
            }
            Error::IncorrectArgumentCount {
                name,
                required,
                found,
            } => format!("incorrect argument count for {name}: required {required}, found {found}"),
            Error::SchemaChecking {
                name,
                required,
                found,
                ..
            } => {
                format!("schema checking failed for {name}: required {required:?}, found {found:?}")
            }
            Error::AggregationArgumentMustBeSelfComparable(aggs, schema) => format!(
                "cannot have {aggs:?} aggregations over the schema: {schema:?} as it is not comparable to itself"
            ),
            Error::InvalidComparison {
                name, left, right, ..
            } => {
                format!("invalid comparison for {name}: {left:?} cannot be compared to {right:?}")
            }
            Error::CannotMergeObjects(s1, s2, sat) => format!(
                "cannot merge objects {s1:?} and {s2:?} as they {sat:?} have overlapping keys"
            ),
            Error::AccessMissingField(field, _) => {
                format!("cannot access field {field} because it does not exist")
            }
            Error::InvalidSubqueryCardinality => {
                "cardinality of the subquery's result set may be greater than 1".to_string()
            }
            Error::SortKeyNotSelfComparable(pos, schema) => format!(
                "sort key at position {pos} is not statically comparable to itself because it has the schema {schema:?}"
            ),
            Error::GroupKeyNotSelfComparable(pos, schema) => format!(
                "group key at position {pos} is not statically comparable to itself because it has the schema {schema:?}"
            ),
            Error::UnwindIndexNameConflict(name) => {
                format!("UNWIND INDEX name '{name}' conflicts with existing field name")
            }
            Error::CollectionNotFound(database, coll) => {
                format!("unknown collection '{coll}' in database '{database}'")
            }
            Error::InvalidBinaryDataType => {
                "Binary data with subtype 3 found in schema".to_string()
            }
            // Pass through the underlying error's message. HigherOrderFunctionWrapper implements
            // user_message() so there will always be user-readable context wrapped around the
            // underlying error's message.
            Error::HigherOrderFunctionWrapper { error, .. } => error.technical_message(),
            Error::NoSuchVariable(name) => {
                format!("variable with name `{name}` not found in schema inference state")
            }
        }
    }
}

pub(crate) const ANY_SCHEMA_ADDENDUM: &str = "An `any type` schema may indicate that schema is not set for the relevant collection or field. Please verify that the schema is set as expected.";

impl Error {
    /// error_message_with_any_schema_addendum checks if any of the provided schemas are Any and, if
    /// so, returns the provided error message with an addendum; otherwise, it returns the provided
    /// error message unaltered. This is useful for customers since they often get confused when
    /// they see something like "Any cannot be compared to Any", etc. This addendum should help them
    /// realize the potential root cause of the issue (missing schema info).
    fn error_message_with_any_schema_addendum(error_msg: String, schemas: Vec<Schema>) -> String {
        if schemas.iter().any(|s| matches!(s, Schema::Any)) {
            format!("{error_msg} {ANY_SCHEMA_ADDENDUM}")
        } else {
            error_msg
        }
    }
}
