use crate::{
    map,
    mir::{schema::Error as mir_error, *},
    schema::{Atomic, NUMERIC_OR_NULLISH, STRING_OR_NULLISH, Schema},
    set, test_schema,
};

test_schema!(
    first_arg_not_string_or_nullish_is_error,
    expected_error_code = 1002,
    expected = Err(mir_error::SchemaChecking {
        name: "Like",
        required: STRING_OR_NULLISH.clone().into(),
        found: NUMERIC_OR_NULLISH.clone().into(),
        var_cause: None,
    }),
    input = Expression::Like(LikeExpr {
        expr: Expression::Reference(("bar", 0u16).into()).into(),
        pattern: Expression::Literal(LiteralValue::String("hello".into())).into(),
        escape: None,
    }),
    schema_env = map! {("bar", 0u16).into() => NUMERIC_OR_NULLISH.clone()},
);

test_schema!(
    first_arg_not_string_or_nullish_is_error_with_var_cause,
    expected_error_code = 1002,
    expected = Err(mir_error::SchemaChecking {
        name: "Like",
        required: STRING_OR_NULLISH.clone().into(),
        found: NUMERIC_OR_NULLISH.clone().into(),
        var_cause: Some("this".to_string()),
    }),
    input = Expression::Like(LikeExpr {
        expr: Expression::Variable(Variable {
            name: "this".to_string(),
            is_nullable: true,
        })
        .into(),
        pattern: Expression::Literal(LiteralValue::String("hello".into())).into(),
        escape: None,
    }),
    variables = map! {
        "this" => NUMERIC_OR_NULLISH.clone(),
    },
);

test_schema!(
    second_arg_not_string_or_nullish_is_error,
    expected_error_code = 1002,
    expected = Err(mir_error::SchemaChecking {
        name: "Like",
        required: STRING_OR_NULLISH.clone().into(),
        found: NUMERIC_OR_NULLISH.clone().into(),
        var_cause: None,
    }),
    input = Expression::Like(LikeExpr {
        expr: Expression::Literal(LiteralValue::String("hello".into())).into(),
        pattern: Expression::Reference(("bar", 0u16).into()).into(),
        escape: None,
    }),
    schema_env = map! {("bar", 0u16).into() => NUMERIC_OR_NULLISH.clone()},
);

test_schema!(
    second_arg_not_string_or_nullish_is_error_with_var_cause,
    expected_error_code = 1002,
    expected = Err(mir_error::SchemaChecking {
        name: "Like",
        required: STRING_OR_NULLISH.clone().into(),
        found: NUMERIC_OR_NULLISH.clone().into(),
        var_cause: Some("this".to_string()),
    }),
    input = Expression::Like(LikeExpr {
        expr: Expression::Literal(LiteralValue::String("hello".into())).into(),
        pattern: Expression::Variable(Variable {
            name: "this".to_string(),
            is_nullable: true
        })
        .into(),
        escape: None,
    }),
    variables = map! {
        "this" => NUMERIC_OR_NULLISH.clone(),
    },
);

test_schema!(
    must_be_string,
    expected = Ok(Schema::Atomic(Atomic::Boolean)),
    input = Expression::Like(LikeExpr {
        expr: Expression::Reference(("bar", 0u16).into()).into(),
        pattern: Expression::Literal(LiteralValue::String("hello".into())).into(),
        escape: None,
    }),
    schema_env = map! {("bar", 0u16).into() => Schema::Atomic(Atomic::String)},
);

test_schema!(
    may_be_null,
    expected = Ok(Schema::AnyOf(set![
        Schema::Atomic(Atomic::Boolean),
        Schema::Atomic(Atomic::Null)
    ])),
    input = Expression::Like(LikeExpr {
        expr: Expression::Reference(("bar", 0u16).into()).into(),
        pattern: Expression::Literal(LiteralValue::String("hello".into())).into(),
        escape: None,
    }),
    schema_env = map! {("bar", 0u16).into() => Schema::AnyOf(set![Schema::Atomic(Atomic::String), Schema::Atomic(Atomic::Null)])},
);

test_schema!(
    may_be_missing,
    expected = Ok(Schema::AnyOf(set![
        Schema::Atomic(Atomic::Boolean),
        Schema::Atomic(Atomic::Null)
    ])),
    input = Expression::Like(LikeExpr {
        expr: Expression::Reference(("bar", 0u16).into()).into(),
        pattern: Expression::Literal(LiteralValue::String("hello".into())).into(),
        escape: None,
    }),
    schema_env = map! {("bar", 0u16).into() => Schema::AnyOf(set![Schema::Atomic(Atomic::String), Schema::Missing])},
);

test_schema!(
    must_be_null,
    expected = Ok(Schema::Atomic(Atomic::Null)),
    input = Expression::Like(LikeExpr {
        expr: Expression::Reference(("bar", 0u16).into()).into(),
        pattern: Expression::Literal(LiteralValue::String("hello".into())).into(),
        escape: None,
    }),
    schema_env = map! {("bar", 0u16).into() => Schema::Atomic(Atomic::Null)},
);
